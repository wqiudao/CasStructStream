# CasStructStream.py

"""
wqiudao@gmail.com https://github.com/wqiudao/CasStructStream
usage: casstructstream [-h] {sCas,rna,msa,pdb2dalidb,structcompare,makedalidb,scatter,extract_af3_results,create_struct_pipeline} ...

A tool for designed for Streamlining identification of CRISPR-Cas systems

positional arguments:
  {sCas,rna,msa,pdb2dalidb,structcompare,makedalidb,scatter,extract_af3_results,create_struct_pipeline}
                        Subcommands
    sCas                Streamlined Scanning of CRISPR-Cas Systems.
    rna                 Draw RNA secondary structure.
    msa                 Run protein multiple sequence alignment.
    pdb2dalidb          Compare a PDB file with DALI database.
    structcompare   Compare a folder of PDB files against a structural database.
    makedalidb          Create DALI database: Converts a set of PDB files to DALI format numbers for subsequent structural searches.
    scatter             Generate scatter plots from a CSV file
    extract_af3_results
                        Extract AF3 prediction results and summary.
    create_struct_pipeline
                        Create shell scripts for a full protein¡§CRNA structure pipeline.

options:
  -h, --help            show this help message and exit


"""


import sys,subprocess,os,argparse,re,datetime,shutil,concurrent.futures,random,gemmi,multiprocessing,json,glob
import matplotlib.pyplot as plt

import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
py_spackages = os.path.dirname(os.path.abspath(__file__))
if py_spackages not in sys.path:
	sys.path.append(py_spackages)
from draw_rna.ipynb_draw import draw_struct
from ete3_lib.ete_view  import *
from ete3_lib  import *
from collections import defaultdict
from draw_rna.mpl2 import *
import matplotlib.ticker as ticker
from matplotlib.lines import Line2D
import matplotlib.gridspec as gridspec
current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
max_threads = min(16, multiprocessing.cpu_count())-1
import matplotlib

matplotlib.use("Agg")   
os.environ["QT_QPA_PLATFORM"] = "offscreen"   

from ete3_lib.tree import Tree
from ete3_lib.main import TreeStyle
import matplotlib.pyplot as plt

from scipy.cluster.hierarchy import to_tree

from concurrent.futures import ThreadPoolExecutor
 
from scipy.cluster.hierarchy import linkage, dendrogram
from scipy.spatial.distance import squareform
 
allowed_methods = ['average', 'ward', 'complete', 'single']
 
ESMFOLD_SH_NAME = "run_esmfold_each.sh"
ESMFOLD_SH_CONTENT = r"""#!/bin/bash

# ========== Usage ==========
# bash run_esmfold_each.sh input.fasta
# This script runs esm-fold on each sequence in a multi-entry FASTA file
# One sequence is processed at a time with temporary file, output .pdbs saved in esmfold_results/
# Logs from all runs are saved in a single log file based on the input FASTA filename
# ===========================

# Check usage
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 input.fasta"
    exit 1
fi

input_fasta="$1"
output_dir="esmfold_results"
mkdir -p "$output_dir"

# Generate log filename based on input FASTA
fasta_base=$(basename "$input_fasta")
log_file="${fasta_base%.*}.log"
> "$log_file"  # Clear previous log

seq_name=""
seq_data=""

# Read FASTA line by line
while IFS= read -r line || [ -n "$line" ]; do
    if [[ "$line" == ">"* ]]; then
        if [ -n "$seq_name" ]; then
            tmp_fasta=$(mktemp)
            echo "$seq_name" > "$tmp_fasta"
            echo "$seq_data" >> "$tmp_fasta"

            base=$(echo "$seq_name" | cut -c2- | sed 's/[^A-Za-z0-9_.-]/_/g')
            echo "=== [$base] START ===" >> "$log_file"

            (time esm-fold -i "$tmp_fasta" -o "$output_dir") >> "$log_file" 2>&1

            echo "=== [$base] END ===" >> "$log_file"
            echo "" >> "$log_file"

            rm "$tmp_fasta"
        fi
        seq_name="$line"
        seq_data=""
    else
        seq_data="${seq_data}${line}"
    fi
done < "$input_fasta"

# Handle last sequence
if [ -n "$seq_name" ]; then
    tmp_fasta=$(mktemp)
    echo "$seq_name" > "$tmp_fasta"
    echo "$seq_data" >> "$tmp_fasta"

    base=$(echo "$seq_name" | cut -c2- | sed 's/[^A-Za-z0-9_.-]/_/g')
    echo "=== [$base] START ===" >> "$log_file"

    (time esm-fold -i "$tmp_fasta" -o "$output_dir") >> "$log_file" 2>&1

    echo "=== [$base] END ===" >> "$log_file"
    echo "" >> "$log_file"

    rm "$tmp_fasta"
fi

echo "All predictions completed. Structures saved in $output_dir, log saved in $log_file."
"""

def create_run_esmfold_each_sh():
    if not os.path.exists(ESMFOLD_SH_NAME):
        with open(ESMFOLD_SH_NAME, "w") as f:
            f.write(ESMFOLD_SH_CONTENT)
        os.chmod(ESMFOLD_SH_NAME, 0o755)
        print(f"\n[INFO] {ESMFOLD_SH_NAME} has been created in the current directory.")
        print("\nThis shell script runs esm-fold on each sequence in a multi-entry FASTA file.")
        print(f"Usage:\n  bash {ESMFOLD_SH_NAME} input.fasta\n")
    else:
        print(f"\n[INFO] {ESMFOLD_SH_NAME} already exists in the current directory.")

 
 

HADDOCK_SH_NAME = "run_haddock3.sh"
HADDOCK_SH_CONTENT = r"""#!/bin/bash

# ========== Usage ==========
# bash run_haddock3.sh protein.pdb rna.pdb
# This script creates a docking folder, builds HADDOCK3 config, and runs docking via Docker
# ===========================

protein_file="$1"
rna_file="$2"

# ======= Check input =======
if [[ ! -f "$protein_file" || ! -f "$rna_file" ]]; then
    echo "[ERROR] Input PDB files not found!"
    echo "Usage: $0 protein.pdb rna.pdb"
    exit 1
fi

# ======= Parse names =======
protein_base=$(basename "$protein_file")
rna_base=$(basename "$rna_file")
protein_name="${protein_base%%.*}"
rna_name="${rna_base%%.*}"
target_dir="docking_${protein_name}_${rna_name}"

# ======= Create directory and copy files =======
mkdir -p "$target_dir/data"
cp "$protein_file" "$target_dir/data/$protein_base"
cp "$rna_file" "$target_dir/data/$rna_base"

# ======= Create HADDOCK3 config file =======
cat > "$target_dir/cas-crrna-docking.cfg" <<EOF
run_dir = "run_${protein_name}"
mode = "local"
ncores = $(nproc)

molecules = [
    "data/${protein_base}",
    "data/${rna_base}"
]

[topoaa]
autohis = false

[flexref]
sampling_factor = 20
tolerance = 20

[emref]
tolerance = 20

[clustfcc]
min_population = 1

[seletopclusts]
top_models = 4
EOF

# ======= Run HADDOCK3 via Docker =======
echo "Running HADDOCK3 for ${protein_base} and ${rna_base}"
docker run --rm \
  -u $(id -u):$(id -g) \
  -v "$(pwd)/$target_dir":/data \
  haddock3 /data/cas-crrna-docking.cfg
"""


def create_run_haddock3_sh():
    if not os.path.exists(HADDOCK_SH_NAME):
        with open(HADDOCK_SH_NAME, "w") as f:
            f.write(HADDOCK_SH_CONTENT)
        os.chmod(HADDOCK_SH_NAME, 0o755)
        print(f"\n[INFO] {HADDOCK_SH_NAME} has been created in the current directory.")
        print("\nThis shell script allows you to run HADDOCK3 docking using protein and RNA PDB files.")
        print(f"Usage:\n  bash {HADDOCK_SH_NAME} protein.pdb rna.pdb\n")
    else:
        print(f"\n[INFO] {HADDOCK_SH_NAME} already exists in the current directory.")


SH_SCRIPT_NAME = "run_af3_auto.sh"
SH_SCRIPT_CONTENT = r"""#!/bin/bash

# ========== Usage ==========
# bash run_af3_auto.sh input.csv|fasta [--id_col N] [--protein_col N] [--rna_col N] [--db /your/db/path]
# All column indexes start from 1 (CSV only)
# Defaults: --id_col 1 --protein_col 2 --rna_col not used --db /data3/Downloads/af3_db
# ===========================

input_file="$1"

# Default values
id_col=1
protein_col=2
rna_col=""
db_path="/data3/Downloads/af3_db"

# Parse optional arguments
shift
while [[ $# -gt 0 ]]; do
    case "$1" in
        --id_col)
            id_col="$2"
            shift 2
            ;;
        --protein_col)
            protein_col="$2"
            shift 2
            ;;
        --rna_col)
            rna_col="$2"
            shift 2
            ;;
        --db)
            db_path="$2"
            shift 2
            ;;
        *)
            echo "[ERROR] Unknown option: $1"
            exit 1
            ;;
    esac
done

# Check file existence
if [ ! -f "$input_file" ]; then
    echo "[ERROR] File not found: $input_file"
    exit 1
fi

echo "========== AF3 Batch Runner =========="
echo "[INFO] Input file     : $input_file"
echo "[INFO] AF3 DB path    : $db_path"
echo "======================================"

# Remove invalid characters from protein sequence
sanitize_protein_sequence() {
    local sequence="$1"
    echo "$sequence" | tr -d -c 'ACDEFGHIKLMNPQRSTVWY'
}

# Convert DNA to RNA
convert_dna_to_rna() {
    local sequence="$1"
    sequence="${sequence%%;*}"
    if [[ ! "$sequence" =~ ^[AUGCTtaugc]+$ ]]; then
        sequence="null"
    fi
    echo "$sequence" | tr 'Tt' 'Uu'
}

# Run AlphaFold3 prediction
run_af3() {
    local protein_id="$1"
    local protein_sequence="$2"
    local rna_sequence="$3"

    protein_sequence=$(sanitize_protein_sequence "$protein_sequence")

    if [[ -n "$rna_sequence" && "$rna_sequence" != "null" ]]; then
        rna_sequence="${rna_sequence%%;*}"
        rna_sequence=$(convert_dna_to_rna "$rna_sequence")
    else
        rna_sequence="null"
    fi

    mkdir -p "$protein_id"

    local json_output=$(cat <<EOF
{
  "name": "$protein_id",
  "modelSeeds": [1,2],
  "sequences": [
    {
      "protein": {
        "id": "A",
        "sequence": "$protein_sequence"
      }
    }$([[ "$rna_sequence" != "null" ]] && echo ",")$([[ "$rna_sequence" != "null" ]] && echo '
    {
      "rna": {
        "id": "B",
        "sequence": "'"$rna_sequence"'"
      }
    }')
  ],
  "dialect": "alphafold3",
  "version": 1
}
EOF
)

    echo "$json_output" > "$protein_id/fold_input.json"
    echo "[INFO] JSON saved: $protein_id/fold_input.json"

    local total_cpus=$(nproc)
    local half_cpus=$((total_cpus / 1))

    docker run --rm \
        --volume "$PWD/$protein_id:/root/af_input" \
        --volume "$PWD/$protein_id:/root/af_output" \
        --volume "$db_path:/root/public_databases" \
        --gpus all \
        alphafold3 \
        python run_alphafold.py --nhmmer_n_cpu "$half_cpus" \
            --json_path=/root/af_input/fold_input.json \
            --model_dir=/root/public_databases \
            --output_dir=/root/af_output
}

# Detect file type and process
if [[ "$input_file" == *.csv ]]; then
    echo "[INFO] Detected CSV format"
    echo "[INFO] ID column      : $id_col"
    echo "[INFO] Protein column : $protein_col"
    echo "[INFO] RNA column     : ${rna_col:-None}"
    awk -F',' -v id_col="$id_col" -v protein_col="$protein_col" -v rna_col="$rna_col" '{
        gsub(/ /, "", $id_col)
        gsub(/ /, "", $protein_col)
        if (rna_col != "") gsub(/ /, "", $rna_col)
        print $id_col "\t" $protein_col "\t" (rna_col != "" ? $rna_col : "null")
    }' "$input_file" | while IFS=$'\t' read -r protein_id protein_sequence rna_sequence; do
        if [[ -z "$protein_id" || -z "$protein_sequence" ]]; then continue; fi
        if [[ ${#protein_sequence} -lt 400 ]]; then continue; fi
        run_af3 "$protein_id" "$protein_sequence" "$rna_sequence"
    done

elif [[ "$input_file" == *.fasta || "$input_file" == *.fa ]]; then
    echo "[INFO] Detected FASTA format"
    awk '/^>/ {if(seq){print name"\t"seq}; name=substr($0,2); seq=""} /^[^>]/ {seq=seq""$0} END{if(seq){print name"\t"seq}}' "$input_file" | \
    while IFS=$'\t' read -r protein_id protein_sequence; do
        if [[ -z "$protein_id" || -z "$protein_sequence" ]]; then continue; fi
        if [[ ${#protein_sequence} -lt 400 ]]; then continue; fi
        run_af3 "$protein_id" "$protein_sequence" "null"
    done

else
    echo "[ERROR] Unsupported input format. Please use .csv or .fasta/.fa"
    exit 1
fi


"""

def check_and_create_sh():
    if not os.path.exists(SH_SCRIPT_NAME):
        with open(SH_SCRIPT_NAME, "w") as f:
            f.write(SH_SCRIPT_CONTENT)
        print(f"\n[INFO] {SH_SCRIPT_NAME} has been created in the current directory.")
        print("\nThis shell script allows you to batch run AlphaFold3 predictions from a CSV file.")
        print("You can specify which columns contain Protein ID, Protein sequence, and optional RNA sequence.")
        print(f"Usage example:\n  bash {SH_SCRIPT_NAME} input.csv --id_col 1 --protein_col 2 --rna_col 16\n")
    else:
        print(f"\n[INFO] {SH_SCRIPT_NAME} already exists in current directory.")
    create_run_haddock3_sh()
    create_run_esmfold_each_sh()

def find_result_txt(path='.'):
    """
    Automatically find a result .txt file in a given path:
    - Prefer files starting with 'mol'
    - Otherwise fallback to any .txt file
    Returns the filename (with full path) if found, else raises an error.
    """
    # Ensure path is absolute
    path = os.path.abspath(path)

    mol_txt_files = glob.glob(os.path.join(path, "mol*.txt"))
    
    if mol_txt_files:
        return os.path.basename(mol_txt_files[0])
    else:
        all_txt_files = glob.glob(os.path.join(path, "*.txt"))
        if all_txt_files:
            return os.path.basename(all_txt_files[0])
        else:
            raise False

def extract_af3_results(input_dir, output_dir=None, plot_style="balanced"):
	input_dir = os.path.abspath(input_dir)
	input_basename = os.path.basename(os.path.normpath(input_dir))

	if output_dir is None:
		# Always create in current working directory
		output_dir = os.path.join(os.getcwd(), f"{input_basename}_extracted_results")
	os.makedirs(output_dir, exist_ok=True)

	print(f"\n[INFO] Scanning: {input_dir}")
	extracted_count = 0
	summary_dict = {}

	for subfolder in os.listdir(input_dir):
		subfolder_path = os.path.join(input_dir, subfolder)
		if os.path.isdir(subfolder_path):
			cif_file = None
			json_file = None

			# Search subdirectory
			for root, dirs, files in os.walk(subfolder_path):
				for file in files:
					if file.endswith("_model.cif"):
						cif_file = os.path.join(root, file)
					if file.endswith("summary_confidences.json"):
						json_file = os.path.join(root, file)
				if cif_file and json_file:
					break

			if cif_file and json_file:
				# Copy
				shutil.copy(cif_file, os.path.join(output_dir, os.path.basename(cif_file)))
				shutil.copy(json_file, os.path.join(output_dir, os.path.basename(json_file)))
				print(f"[OK] Extracted from {subfolder}:")
				print(f"     {os.path.basename(cif_file)}")
				print(f"     {os.path.basename(json_file)}")
				extracted_count += 1

				# Extract summary info
				with open(json_file) as f:
					data = json.load(f)
					summary_dict[subfolder] = {
						"fraction_disordered": data.get("fraction_disordered", None),
						"has_clash": data.get("has_clash", None),
						"iptm": data.get("iptm", None),
						"ptm": data.get("ptm", None),
						"ranking_score": data.get("ranking_score", None)
					}
			else:
				print(f"[WARNING] No complete result found in {subfolder}")

	print(f"\n[INFO] {extracted_count} result(s) extracted to: {output_dir}")

	# Save summary CSV
	df = pd.DataFrame.from_dict(summary_dict, orient="index")
	df.index.name = "Case_ID"
	summary_path = os.path.join(output_dir, "af3_summary_info.csv")
	df.to_csv(summary_path)
	print(f"[INFO] Summary information saved to: {summary_path}")

	# Plot
	# if do_plot:
	pdf_path = os.path.join(output_dir, "af3_summary_report.pdf")
	plot_af3_summary_all(summary_path, pdf_path, ymax=1.0, style=plot_style)


def mix_colors(color1, color2):
    """Mix two HEX colors and return middle color"""
    c1 = tuple(int(color1[i:i+2], 16) for i in (1, 3, 5))
    c2 = tuple(int(color2[i:i+2], 16) for i in (1, 3, 5))
    mixed = tuple((c1[i] + c2[i]) // 2 for i in range(3))
    return '#{:02x}{:02x}{:02x}'.format(*mixed)

def plot_af3_summary_all(summary_csv, output_pdf, ymax=1.0, style="balanced"):
    df = pd.read_csv(summary_csv, index_col=0)
    total_points = len(df)

    variables = ["fraction_disordered", "has_clash", "iptm", "ptm", "ranking_score"]
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
    color_map = {var: colors[i % len(colors)] for i, var in enumerate(variables)}

    # Mixed color for scatter plot
    scatter_color = mix_colors(color_map["iptm"], color_map["ptm"])

    # --- Create figure ---
    fig = plt.figure(figsize=(14, 8))
    gs = gridspec.GridSpec(2, 2, height_ratios=[0.2, 1])  # Top row for legend

    # --- Left: Scatter plot ---
    ax1 = fig.add_subplot(gs[1, 0])
    ax1.scatter(df["iptm"], df["ptm"],
                color=scatter_color, edgecolor="black", s=60, alpha=0.8)

    # Invisible correction point
    ax1.scatter(0, 0, alpha=0)

    # Reference lines
    ax1.axvline(x=0.7, color='gray', linestyle='--', linewidth=1)
    ax1.axhline(y=0.7, color='gray', linestyle='--', linewidth=1)

    # Labels & aspect
    ax1.set_xlabel("iptm", fontsize=12)
    ax1.set_ylabel("ptm", fontsize=12)
    ax1.set_title(f"AF3 Predicted iptm vs ptm (Total={total_points})", fontsize=13)
    ax1.set_facecolor("white")
    ax1.grid(False)
    if style == "square":
        ax1.set_aspect('equal', adjustable='box')
    elif style == "balanced":
        ax1.set_aspect(0.9)

    # --- Right: Beeswarm plot ---
    ax2 = fig.add_subplot(gs[1, 1])

    for i, var in enumerate(variables):
        sub_df = df[[var]].dropna()
        for _, row in sub_df.iterrows():
            jitter_x = i + (random.uniform(-0.1, 0.1))
            ax2.plot(jitter_x, row[var], 'o',
                     markersize=7,
                     markeredgecolor="black",
                     markerfacecolor=color_map[var],
                     markeredgewidth=0.3)

    ax2.set_xticks(range(len(variables)))
    ax2.set_xticklabels(variables, rotation=45, ha="right")
    ax2.set_xlim(-0.5, len(variables) - 0.5)
    ax2.set_ylim(0, ymax)
    ax2.yaxis.set_major_locator(ticker.MultipleLocator(0.1))
    ax2.set_facecolor("white")
    ax2.grid(False)
    ax2.set_title(f"AF3 Summary Metrics (Total={total_points})")
    ax2.set_xlabel("Metrics")
    ax2.set_ylabel("Value")

    # --- Legend at top ---
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', label=var,
               markerfacecolor=color_map[var], markeredgecolor='black', markersize=8, markeredgewidth=0.3)
        for var in variables
    ]

    fig.legend(handles=legend_elements,
               loc='upper center',
               ncol=5,
               frameon=False,
               fontsize=10,
               title="AF3 Metrics",
               bbox_to_anchor=(0.5, 0.95))

    # --- Save PDF ---
    with PdfPages(output_pdf) as pdf:
        plt.tight_layout(rect=[0, 0, 1, 0.92])  # Space for legend
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)

    print(f"[INFO] Summary report saved to: {output_pdf}")



# Function: plot scatter with gray background and colored foreground points
def plot_scatter(df_all, df_subset, ax, title, x_col, y_col, category, color_map=None,axvline=70,axhline=0.7):
    unique_categories = df_all[category].fillna('').unique()
    if color_map is None:
        colors = ["#9467bd", "#2ca02c", "#1f77b4", "#ff7f0e", "#d62728",
                  "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"]
        color_map = {str(cat): colors[i % len(colors)] for i, cat in enumerate(unique_categories)}

    # Plot all data as gray background
    ax.scatter(df_all[x_col], df_all[y_col],
               color='#dddddd', edgecolor='none',
               alpha=0.3, s=40, label=None)

    # Add (0,0) invisible correction point
    ax.scatter(0, 0, alpha=0)

    # Plot the current category as colored foreground
    plotted = False
    subset_categories = df_subset[category].fillna('').unique()
    for cat in subset_categories:
        group = df_subset[df_subset[category].astype(str) == str(cat)]
        if not group.empty:
            display_cat = '(blank)' if cat.strip() == '' else cat
            ax.scatter(group[x_col], group[y_col],
                       label=f"{category} = {display_cat}",
                       alpha=0.85,
                       color=color_map.get(str(cat), 'grey'),
                       edgecolor='black',
                       s=60)
            plotted = True

    # Reference lines
    ax.axvline(x=axvline, color='gray', linestyle='--', linewidth=1)
    ax.axhline(y=axhline, color='gray', linestyle='--', linewidth=1)
    ax.set_xlabel(x_col, fontsize=10)
    ax.set_ylabel(y_col, fontsize=10)
    ax.set_title(title, fontsize=12)

    if plotted:
        ax.legend(title=category, fontsize=8)
    else:
        ax.text(0.5, 0.5, 'No data available', ha='center', va='center',
                transform=ax.transAxes, fontsize=12, color='red')


def ScatterStruct(csv_path, x_col, y_col, category, output_pdf,axvline=70,axhline=0.7):
    df = pd.read_csv(csv_path)

    if not output_pdf:
        base_name = os.path.splitext(os.path.basename(csv_path))[0]
        output_pdf = f"scatter_{base_name}_{category}.pdf"
    else:
        output_pdf=f'{output_pdf}.pdf'

    df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
    df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
    df[category] = df[category].fillna('').astype(str)
    df_plot = df.dropna(subset=[x_col, y_col, category])
    unique_categories = sorted(df_plot[category].unique())

    colors = ["#9467bd", "#2ca02c", "#1f77b4", "#ff7f0e", "#d62728",
              "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"]
    color_map = {str(cat): colors[i % len(colors)] for i, cat in enumerate(unique_categories)}

    # Prepare all tasks: the first one is the entire dataset, followed by each category
    plot_tasks = [('ALL', df_plot)] + [(cat, df_plot[df_plot[category] == cat]) for cat in unique_categories]

    with PdfPages(output_pdf) as pdf:
        plots_per_page = 6
        total_plots = len(plot_tasks)
        pages = (total_plots + plots_per_page - 1) // plots_per_page

        task_index = 0
        for page in range(pages):
            fig, axs = plt.subplots(2, 3, figsize=(18, 12), facecolor='white')
            axs = axs.flatten()

            for ax in axs:
                if task_index < total_plots:
                    task_label, df_sub = plot_tasks[task_index]
                    if task_label == 'ALL':
                        title = f"All Data Colored by {category}"
                    else:
                        display_cat = '(blank)' if task_label.strip() == '' else task_label
                        title = f"{category} = {display_cat}"

                    plot_scatter(df_plot, df_sub, ax, title,x_col, y_col, category,color_map,axvline,axhline)
                    task_index += 1
                else:
                    fig.delaxes(ax)

            plt.tight_layout()
            pdf.savefig(fig, bbox_inches='tight')
            plt.close(fig)

    print(f"Scatter plots saved to {output_pdf}")


def parse_structalignpro_results(filepath):
	with open(filepath, 'r') as f:
		content = f.read()

	header_match = re.search(r">>>(.*?)<<<", content)
	if not header_match:
		return {}
	name = header_match.group(1)  # seq_304_sCas_304.pdb
	scas_id = os.path.splitext(name)[0]  # ¨¨£¤¦Ì? .pdb -> seq_304_sCas_304

	# _, scas_id = header_match.groups()
 
	with open(filepath, 'r') as f:
		contents = [line.rstrip('\n') for line in f.readlines()]

	if contents:
		for content in contents:
			match=re.split(r',',content)
			if len(match)>6:
				chain, z, rmsd, lali, nres, pid,pdb_cas,pdb_desc = match[2],match[3],match[4],match[5],match[6],match[7],match[-2],match[-1]
				 
				
				return {
					f"{scas_id}": {
						"Chain": chain,
						"Z": float(z),
						"RMSD": float(rmsd),
						"LALI": int(lali),
						"NRES": int(nres),
						"%ID": float(pid),
						"pdb_cas":pdb_cas,
						"pdb_desc": pdb_desc
					}
				}
	else:
		print(f"{scas_id} fail")
		return {}

def scan_structalignpro_directory(directory):
    results = {}
    for filename in os.listdir(directory):
        if filename.startswith("StructAlignPro") and filename.endswith("_result.txt"):
            filepath = os.path.join(directory, filename)
            result = parse_structalignpro_results(filepath)
            if result is None:
                print(f"[WARN] Skipped file with no result: {filename}")
                continue
            results.update(result)
    return results



def scan_structalignpro_all_hits(directory, z_threshold=8.0):
	all_hits = []
	pdb_cas_hits = set()

	for filename in os.listdir(directory):
		if filename.startswith("StructAlignPro") and filename.endswith("_result.txt"):
			filepath = os.path.join(directory, filename)
			scas_id = filename.replace("StructAlignPro_", "").replace("_result.txt", "")

			with open(filepath, 'r') as f:
				contents = [line.rstrip('\n') for line in f.readlines()]

			if contents:
				for content in contents:
				
					match=re.split(r',',content)
					if len(match)>6:
						chain, z, rmsd, lali, nres, pid,pdb_cas,pdb_desc = match[2],match[3],match[4],match[5],match[6],match[7],match[-2],match[-1]
						z = float(z)
						if z >= z_threshold:
							all_hits.append({
								"sCas_ID": scas_id,
								"Chain": chain,
								"Z": z,
								"rmsd": float(rmsd),
								"lali": int(lali),
								"nres": int(nres),
								"%id": float(pid),
								"pdb_cas":pdb_cas,
								"pdb_desc": pdb_desc
							})
							pdb_cas_hits.add(pdb_cas)

	return pd.DataFrame(all_hits),pdb_cas_hits
 

def copy_similar_pdbs(pdb_cas_hits, source_dir="pdb_full_clean", target_dir="?¨¤??pdb"):
	os.makedirs(target_dir, exist_ok=True)
	matched = []
	if source_dir== 'pdb_full_clean':
		source_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), source_dir)

	for fname in os.listdir(source_dir):
		for cas in pdb_cas_hits:
			if cas in fname:
				src = os.path.join(source_dir, fname)
				dst = os.path.join(target_dir, fname)
				shutil.copy2(src, dst)
				matched.append(fname)


	print(f"[INFO] Copied {len(matched)} matched PDB files to: {target_dir}")

def copy_similar_and_original_pdbs(pdb_cas_hits, result_dir, source_ref_dir="pdb_full_clean", target_dir_suffix="_similar_pdbs"):
	target_dir = target_dir_suffix
	os.makedirs(target_dir, exist_ok=True)
	matched = []

	if source_ref_dir== 'pdb_full_clean':
		source_ref_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), source_ref_dir)


	for fname in os.listdir(source_ref_dir):
		if not fname.lower().endswith(".pdb"):
			continue
		for cas in pdb_cas_hits:
			if cas.lower() in fname.lower():
				src = os.path.join(source_ref_dir, fname)
				dst = os.path.join(target_dir, fname)
				shutil.copy2(src, dst)
				matched.append(fname)


	copied_count = 0
	for fname in os.listdir(result_dir):
		if fname.lower().endswith(".pdb"):
			src = os.path.join(result_dir, fname)
			dst = os.path.join(target_dir, fname)
			shutil.copy2(src, dst)
			copied_count += 1

	print(f"[INFO] Copied {copied_count} original PDB files from {result_dir} to: {target_dir}")


def process_structalignpro_result_dir(result_dir,ymax=20,z_threshold=8.0,max_threads=max_threads,width=800,inner_width=28,inner_height=8,linkage_method='average'):
	output_path = f"{result_dir}_structcompare_top_hits.csv"
	pdf_path = f"{result_dir}_structcompare_top.pdf"

	# === Step 1: Parse results ===
	hits = scan_structalignpro_directory(result_dir)

	# for scas_id, data in hits.items():
		# print(f"{scas_id}: Chain={data['Chain']}, Z={data['Z']}")

	df = pd.DataFrame.from_dict(hits, orient="index")
	df.index.name = "sCas_ID"
	df.to_csv(output_path)
	print(f"[INFO] Saved top hit summary to {output_path}")

	# === Step 2: Beeswarm plot ===
	print(f"[INFO] Begin to plot...")
	df = pd.read_csv(output_path)
	df["Z"] = df["Z"].astype(float)
	df["Chain"] = df["Chain"].astype("category")
	chain_order = list(df["Chain"].cat.categories)

	def categorize_z(z):
		if z >= 10:
			return "Z >= 10: Strongly Conserved"
		elif z >= 8:
			return "Z >= 8: Structurally Homologous"
		else:
			return "Z < 8"

	df["Z_Category"] = df["Z"].apply(categorize_z)

	color_map = {
		"Z >= 10: Strongly Conserved": "#1b9e77",
		"Z >= 8: Structurally Homologous": "#7570b3",
		"Z < 8": "#d95f02"
	}

	num_chains = len(chain_order)
	fig_width = max(6, 0.35 * num_chains + 1)
	final_ymax = max((int(df["Z"].max() / 5) + 1) * 5, ymax)
	with PdfPages(pdf_path) as pdf:
		fig = plt.figure(figsize=(fig_width, 6.2))
		gs = gridspec.GridSpec(2, 1, height_ratios=[0.3, 1])

		ax_legend = fig.add_subplot(gs[0])
		ax_legend.axis("off")

		legend_elements = [
			Line2D([0], [0], marker='o', color='w', label=k,
				   markerfacecolor=v, markeredgecolor='black', markersize=8, markeredgewidth=0.3)
			for k, v in color_map.items()
		] + [
			Line2D([0], [0], color='gray', linestyle='--', label='Z = 8 Threshold'),
			Line2D([0], [0], color='black', linestyle='--', label='Z = 10 Threshold'),
		]

		ax_legend.legend(handles=legend_elements, loc="center", ncol=2,
						 title="Z-score Interpretation", frameon=False)

		ax = fig.add_subplot(gs[1])
		for i, chain in enumerate(chain_order):
			sub_df = df[df["Chain"] == chain]
			for _, row in sub_df.iterrows():
				jitter_x = i + (random.uniform(-0.1, 0.1))
				color = color_map[row["Z_Category"]]
				ax.plot(jitter_x, row["Z"], 'o',
						markersize=7,
						markeredgecolor="black",
						markerfacecolor=color,
						markeredgewidth=0.3)

		ax.axhline(8, color="gray", linestyle="--", linewidth=1)
		ax.axhline(10, color="black", linestyle="--", linewidth=1)

		ax.set_xticks(range(len(chain_order)))
		ax.set_xticklabels(chain_order, rotation=45, ha="right")
		ax.set_xlim(-0.5, len(chain_order) - 0.5)
		ax.set_ylim(0, final_ymax)
		ax.yaxis.set_major_locator(ticker.MultipleLocator(2))
		ax.set_facecolor("white")
		ax.grid(False)

		ax.set_title("Z-score per Chain (Z >= 8 and Z >= 10 Thresholds)")
		ax.set_xlabel("Chain")
		ax.set_ylabel("Z-score")

		plt.tight_layout(h_pad=1.5)
		pdf.savefig(fig)
		plt.close(fig)

	print(f"[INFO] Plot saved to: {pdf_path}")

	# === Step 3: Extract all hits with Z >= 8 and save to CSV ===
	
	
	
	df_all_hits,pdb_cas_hits = scan_structalignpro_all_hits(result_dir, z_threshold=z_threshold)
	all_hits_csv_path = f"{result_dir}_structcompare_all_hits_z_{z_threshold}.csv"
	df_all_hits.to_csv(all_hits_csv_path, index=False)
	print(f"[INFO] Saved all hits with Z >= 8.0 to {all_hits_csv_path}")



	print(pdb_cas_hits)

	
	target_dir_suffix=f"{result_dir}_similar_{current_time}"

	copy_similar_and_original_pdbs(pdb_cas_hits,result_dir,source_ref_dir="pdb_full_clean", target_dir_suffix=target_dir_suffix)
	
	compute_dali_matrix(
		target_dir_suffix,
		max_threads=max_threads,
		width=width,
		inner_width=inner_width,
		inner_height=inner_height,
		linkage_method=linkage_method
	)


 

def remove_extension(pdb_file):
	file_name, _ = os.path.splitext(pdb_file)
	return file_name
def replace_mol1_in_file(mol_txt, new_name1, new_name2=0):
	if not os.path.isfile(mol_txt):
		print(f"\033[91mERROR: The absence of the result file '{mol_txt}' indicates that DaliLite did not run correctly. This may be due to improper configuration of the dependency environment.\033[0m")
		return
	with open(mol_txt, 'r') as f:
		content = f.read()
	if new_name2:	  
		updated_content = content.replace("mol1", remove_extension(new_name1)).replace("mol2", remove_extension(new_name2))
	else:
		updated_content = content.replace("mol1", remove_extension(new_name1))

	with open(mol_txt, 'w') as f:
		f.write(updated_content)


def makedalidb(src_directory,dest_directory,random_number=1000,bin_dali='lib_exc'):
	new_names_dali=set()
	new_names_dali2symbol={}
	log_file=f'{dest_directory}/dali.log'
	hash_file=f'{dest_directory}/dali.hash'
	list_file_path=f'{dest_directory}/dali.list'
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)	
	# pdb_files_with_random = {}
	old2new_names = {}
	new2ole_names = {}
	for root, dirs, files in os.walk(src_directory):
		for file in files:
			if file.endswith('.pdb'):
				random_number += 1
				new_filename = f"{random_number}.pdb"
				src_file_path = os.path.join(root, file)
				dest_file_path = os.path.join(dest_directory, new_filename)
				
				shutil.copy(src_file_path, dest_file_path)
				new_names_dali.add(dest_file_path)
				new_names_dali2symbol[dest_file_path]=str(random_number)
				old2new_names[file] = new_filename
				new2ole_names[str(random_number)] = file
				# print(f'{file} {new_filename}')
	log_file=open(log_file, 'w')
	hash_file=open(hash_file, 'w')
	list_file=open(list_file_path, 'w')
	for old_name, new_name in old2new_names.items():
		old_name=old_name.split('.')[0]
		new_name=new_name.split('.')[0]
		
		# hash_file.write(f"Old Name: {old_name}, New Name: {new_name}\n")
		hash_file.write(f"{new_name},{old_name},{old_name},{old_name},{old_name}\n")
		list_file.write(f"{new_name}\n")
	hash_file.close()
	list_file.close()
	command = ['chmod', '-R', '+x', os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}']
	result = subprocess.run(command, check=True, capture_output=True, text=True)
	perl_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}/import.pl'
	for filename in new_names_dali:
		# print(f'{new2ole_names[new_names_dali2symbol[filename]]} {filename}')
		# print(new_names_dali2symbol[filename])  running  run_Log
		result = subprocess.Popen(
			['perl', perl_script, '--pdbfile', filename, '--pdbid', new_names_dali2symbol[filename], '--dat', dest_directory, '--clean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
		)
		stdout, stderr = result.communicate()		
		log_file.write(f">>>{new2ole_names[new_names_dali2symbol[filename]]} {filename}<<<\n\n") 
		log_file.write(f"{stdout.decode('utf-8')}")  
		log_file.write(f"{stderr.decode('utf-8')}\n\n") 		
	ref_dali_db=f"{os.getcwd()}/{dest_directory}"
	run_script = 'casstructstream pdb2dalidb --dali_database'
	run_script1 = 'casstructstream structcompare --dali_database'
	print(f"\n{ref_dali_db}\n")
	log_file.close()
	log_file=open(dest_directory+".dali_ref.log", 'w')
	log_file.write(f"{run_script} {ref_dali_db} entry.pdb\n")	
	log_file.write(f"{run_script1} {ref_dali_db} entry.pdb\n")	
	log_file.close()

	dat_entries = []
	for fname in os.listdir(dest_directory):
		if fname.endswith('.dat'):
			base_name = os.path.splitext(fname)[0]
			dat_entries.append(base_name)
	with open(list_file_path, 'w') as list_file:
		for entry in sorted(dat_entries):
			list_file.write(f"{entry}\n")

 
def hash2info(pdb2id):

	id2pdb=defaultdict(str) #hash filename  mol1A.txt
	id2pdbinfo=defaultdict(list) #hash filename  mol1A.txt
	id2pdbfile=defaultdict(list) #hash filename  pdbfile
	pdb2id_file=open(pdb2id)
	reads=pdb2id_file.readline()

	# 1053,HNH_OgeuIscB_8csz,OgeuIscB,8csz,OgeuIscB
	# 1054,RuvC_Cas12h_9l12,Cas12h,9l12,Cas12h
	# 4cmp,SpyCas9,4cmp_SpyCas9.pdb
	# 4ogc,Cas9,4ogc_Cas9.pdb	

	while reads:
		
		reads=re.sub(r'[\r\n]+', '', reads)
		
		
		readss=re.split(r',',reads)
		if len(readss)>3:
			pdb_id,pdb_symbol,pdb_cas,pdb_desc = readss[0],readss[1],readss[2],readss[3]
			# pdb_desc=f'{pdb_desc}\n'
			if pdb_symbol and pdb_id:
				id2pdb[pdb_id]=pdb_symbol
				id2pdbinfo[pdb_symbol]=[pdb_cas,pdb_desc]
		elif len(readss)>2:	
			id2pdbfile[readss[0]]=readss[2]		
			id2pdbfile[readss[1]]=readss[2]		
		reads=pdb2id_file.readline()
	pdb2id_file.close()

	return id2pdb,id2pdbinfo,id2pdbfile



def recover_name(pdb2id, query,out_file,pdb,ref_dali_db):
	# id2pdb=defaultdict(str) # hash filename  mol1A.txt
	pdbinfos=defaultdict(list) # pdbinfos
	zpdbs=set() # > 6 
	
	id2pdb,id2pdbinfo,id2pdbfile=hash2info(pdb2id)
 

	# pdb2id_file=open(pdb2id)
	# reads=pdb2id_file.readline()
	# while reads:
		# readss=re.split(r',',reads)
		# if len(readss)>3:
			# pdb_id,pdb_symbol,pdb_cas,pdb_desc = readss[0],readss[1],readss[2],readss[4]
			
			# if pdb_symbol and pdb_id:
				# id2pdb[pdb_id]=pdb_symbol
				# # id2pdb[pdb_id+'-A']=pdb_symbol
				# # id2pdbinfo[pdb_symbol]=f'{pdb_cas}	{pdb_desc}'
				# id2pdbinfo[pdb_symbol]=[pdb_cas,pdb_desc]
				
		# reads=pdb2id_file.readline()
	# pdb2id_file.close()



	query_symbol=open(out_file,'w')
	query_symbol.write(f">>>{pdb} {ref_dali_db}<<<\n\n") 	
	query_file=open(query)
	reads=query_file.readline()
	while reads:
		readss=re.split(r'\s+',reads)
		if len(readss)>2 and ('-matrix' not in reads):
			readsss=re.split(r'-',readss[2])
			readss[2]=readsss[0]
			old_name=readss[2]
 
	
			
			new_name=id2pdb[old_name]
			if new_name:
				
				
				if float(readss[3])>=6:
					# print(readss)
					
					pdb_cas,pdb_desc=id2pdbinfo[new_name]
					# print(pdb_cas,pdb_desc)
					
					if pdb_cas in id2pdbfile:
						zpdbs.add(id2pdbfile[pdb_cas])
					if pdb_desc in id2pdbfile:
						zpdbs.add(id2pdbfile[pdb_desc])
									
				readss[2]=new_name
	 
				readss.extend(id2pdbinfo[new_name])

				# print(",".join(readss))
				readss.pop(0)
				reads=",".join(readss)
				
		query_symbol.write(f'{reads}\n')
		reads=query_file.readline()
	query_file.close()
	query_symbol.close()
	return zpdbs
 


def pdb2dalidb(pdb,ref_dali_db,getcwd_pdb,bin_dali='lib_exc',width=800,inner_width=28,inner_height=8,linkage_method='average'):
	print(f"\033[92m{current_time}\033[0m")
	ref_dali_db_log=ref_dali_db
	if ref_dali_db== 'StructCores':
		ref_dali_db = os.path.join(os.path.dirname(os.path.abspath(__file__)), ref_dali_db)

	filename=f'{getcwd_pdb}/{pdb}'
	# ref_dali_db = ref_dali_db.rstrip('/')	
	if not os.path.isabs(ref_dali_db):
		ref_dali_db = os.path.join(os.getcwd(), ref_dali_db)
	# max_length = 70
	# if len(filename) > max_length or len(ref_dali_db) > max_length:
		# print(f"\033[91mERROR: Input parameters must not exceed 70 characters.\nThe full path of the directory where the file is located is too lengthy.\033[0m")	
		# print(f"\033[91m{filename}\033[0m")	
		# print(f"\033[91m{ref_dali_db}\033[0m")	
	if not os.path.isdir(ref_dali_db):
		raise FileNotFoundError(f"{ref_dali_db} is not a directory.")
	required_files = ['dali.hash', 'dali.list']
	for file in required_files:
		if not os.path.isfile(os.path.join(ref_dali_db, file)):
			raise FileNotFoundError(f"{file} not found in {ref_dali_db}.")

	dali_ref_list=f'{ref_dali_db}/dali.list'
	dali2symbol=f'{ref_dali_db}/dali.hash'
	# dest_directory=pdb.split(".")[0]+'_dali_rs'
	dest_directory=f'StructAlignPro_{pdb.split(".")[0]}_{current_time}_running'
	dest_directory1=f'{pdb.split(".")[0]}'
	# log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{datetime.datetime.now()}.run.log'
	out_file=f'{getcwd_pdb}/StructAlignPro_{pdb.split(".")[0]}_{current_time}_result.txt'
	# log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{datetime.datetime.now()}.run.log'
	# log_file=open(log_file, 'w')
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)		
	shutil.copy(filename, dest_directory)
	print(filename)	
	# print(dali_ref_list)
	# print(dali2symbol)
	# print(f"{os.getcwd()}")
	perl_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}/dali.pl'
	os.chdir(dest_directory)

	if pdb.endswith('.cif'):
		cif_file=pdb
		structure = gemmi.read_structure(cif_file)
		pdb=f'{remove_extension(cif_file)}.pdb'
		structure.write_pdb(pdb)	

	os.symlink(pdb, 'pdbfile1')	
	os.symlink(ref_dali_db, 'ref_dali_db_short')	

	result = subprocess.Popen(
		['perl', perl_script, '--pdbfile1', 'pdbfile1', '--db', dali_ref_list, '--dat1','.', '--dat2', 'ref_dali_db_short', '--title', pdb, '--outfmt','summary,alignments,equivalences,transrot', '--clean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
	)
	stdout, stderr = result.communicate()

	log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{current_time}.run.log'
	log_file=open(log_file, 'w')

	log_file.write(f">>>{pdb} {ref_dali_db_log}<<<\n\n") 


	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n")
	mol1A=find_result_txt()
	if mol1A:
		replace_mol1_in_file(mol1A, pdb)
		zpdbs=recover_name(dali2symbol, mol1A,out_file,pdb,ref_dali_db_log)
		log_file.close()
		# print(out_file)
		# print(zpdbs)
			
		if 	len(zpdbs)>0:
			os.chdir('..')
			target_dir_suffix=f"{dest_directory1}_similar"

			copy_similar_and_original_pdbs(zpdbs,dest_directory,source_ref_dir="pdb_full_clean", target_dir_suffix=target_dir_suffix)
			
			compute_dali_matrix(
				target_dir_suffix,
				max_threads=max_threads,
				width=width,
				inner_width=inner_width,
				inner_height=inner_height,
				linkage_method=linkage_method
			)


	else:
		print("Failed...")

def pdb2dalidb_thread(pdb_folder, pdb, ref_dali_db, getcwd_pdb, bin_dali='lib_exc'):
	
	pdb=re.split(r'\/',pdb)[1]
	getcwd_pdb=f'{getcwd_pdb}/{pdb_folder}'
	ref_dali_db_log=ref_dali_db
	if ref_dali_db== 'StructCores':
		ref_dali_db = os.path.join(os.path.dirname(os.path.abspath(__file__)), ref_dali_db)
	filename=f'{getcwd_pdb}/{pdb}'
	# ref_dali_db = ref_dali_db.rstrip('/')	
	if not os.path.isabs(ref_dali_db):
		ref_dali_db = os.path.join(os.getcwd(), ref_dali_db)
	# max_length = 70
	# if len(filename) > max_length or len(ref_dali_db) > max_length:
		# print(f"\033[91mERROR: Input parameters must not exceed 70 characters.\nThe full path of the directory where the file is located is too lengthy.\033[0m")	
		# print(f"\033[91m{filename}\033[0m")	
		# print(f"\033[91m{ref_dali_db}\033[0m")	
	if not os.path.isdir(ref_dali_db):
		raise FileNotFoundError(f"{ref_dali_db} is not a directory.")
	required_files = ['dali.hash', 'dali.list']
	for file in required_files:
		if not os.path.isfile(os.path.join(ref_dali_db, file)):
			raise FileNotFoundError(f"{file} not found in {ref_dali_db}.")
	dali_ref_list=f'{ref_dali_db}/dali.list'
	dali2symbol=f'{ref_dali_db}/dali.hash'
	dest_directory=f'StructAlignPro_{pdb.split(".")[0]}_{current_time}_running'
	out_file=f'{getcwd_pdb}/StructAlignPro_{pdb.split(".")[0]}_{current_time}_result.txt'
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)		
	shutil.copy(filename, dest_directory)
	perl_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}/dali.pl'
	if pdb.endswith('.cif'):
		cif_file=filename
		structure = gemmi.read_structure(cif_file)
		pdb=f'{remove_extension(cif_file)}.pdb'
		structure.write_pdb(f'{getcwd_pdb}/{pdb}')	


	link_pdbfile1 = os.path.join(dest_directory, 'pdbfile1')
	if not os.path.exists(link_pdbfile1):
		os.symlink(pdb, link_pdbfile1) 
	link_refdb = os.path.join(dest_directory, 'ref_dali_db_short')
	relative_db = os.path.relpath(ref_dali_db, start=dest_directory)
	if not os.path.exists(link_refdb):
		os.symlink(relative_db, link_refdb)	
	result = subprocess.Popen(
		['perl', perl_script, '--pdbfile1', 'pdbfile1', '--db', dali_ref_list, '--dat1','.', '--dat2', 'ref_dali_db_short', '--title', pdb, '--outfmt','summary,alignments,equivalences,transrot', '--clean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=dest_directory
	)
	stdout, stderr = result.communicate() 
	log_file=f'{dest_directory}/{pdb.split(".")[0]}_pdb2dalidb_{current_time}.run.log'
	log_file=open(log_file, 'w')
	log_file.write(f">>>{pdb} {ref_dali_db_log}<<<\n\n") 
	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n")
	
	mol1A=find_result_txt(dest_directory)
	# print(f'mol1A {mol1A}\n dest_directory {dest_directory}')
	if mol1A:
		replace_mol1_in_file(f"{dest_directory}/{mol1A}", f'{dest_directory}/{pdb}')
		recover_name(dali2symbol,f'{getcwd_pdb}/{dest_directory}/{mol1A}',out_file,pdb,ref_dali_db_log)
		log_file.close()
		print(pdb)
	else:
		print("Failed...")


def structcompare(pdb_folder, ref_dali_db, getcwd_pdb, bin_dali='lib_exc',max_threads=max_threads,ymax=20,z_threshold=8.0,width=800,inner_width=28,inner_height=8,linkage_method='average'):
	# Step 1: Collect all .pdb or .cif files in the given folder
	print(f"\033[92m{current_time}\033[0m")	
	structure_files = [
		os.path.join(pdb_folder, f)
		for f in os.listdir(pdb_folder)
		if f.lower().endswith('.pdb')
	]
	if not structure_files:
		print(f"\033[91mERROR: No PDB or CIF files found in {pdb_folder}\033[0m")
		return
	print(f"Found {len(structure_files)} structure files in {pdb_folder} for comparing...")
	os.chdir(pdb_folder)
	# Step 2: Use multithreading to run pdb2dalidb_thread in parallel
	with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
		futures = [
			executor.submit(pdb2dalidb_thread,pdb_folder,pdb, ref_dali_db, getcwd_pdb, bin_dali)
			for pdb in structure_files
		]
		# Step 3: Wait for all tasks to complete and raise exceptions if any
		for future in concurrent.futures.as_completed(futures):
			future.result()
	os.chdir("..")
	process_structalignpro_result_dir(pdb_folder,ymax,z_threshold,max_threads,width,inner_width,inner_height,linkage_method)

 
 
 
 
  
 
 
 
 
 
 
def filter_protein_sequence(sequence):
	valid_aa = "ACDEFGHIKLMNPQRSTVWY"
	sequence = re.sub(r'[\s\*]+', '', sequence.upper())
	sequence = re.sub(r'[^' + valid_aa + ']', '', sequence)
	return sequence
		
		

def find_motif_in_sequence(sequence, motif = "RxxxxH"):
    motif_regex = motif.replace('x', '.')
    matches = re.finditer(motif_regex, sequence)
    matched_motifs = [sequence[match.start():match.end()] for match in matches]
	
    return f'{' '.join(matched_motifs)},{len(matched_motifs)}'


	

def abs_criprs(str1, str2, str3):
	crispr_info = set()
	crispr_info_strand = defaultdict(str) 
	str1s = re.split(r';', str1)
	str2s = re.split(r';', str2)	
	str3s = re.split(r';', str3)	
	for index, (str1, str2, str3) in enumerate(zip(str1s, str2s, str3s)):
		pattern = re.escape(str2) + r'_'  
		result = re.sub(pattern, '', str1)
		#print(f"Index: {index}, str1: {s1}, str2: {s2}, result: {result}")
		
		results=re.split(r'_',result)
		crispr_info_strand[results[0]]=str3
		crispr_info.add(results[0])
	# print(crispr_info)
	# print(str2)
	return crispr_info,str2,crispr_info_strand

def process_file(exec_bin, outfile_tmp, log_file, fasta_file_path, flanking_length, genome_size, cas_size):
    result = subprocess.Popen(
        [exec_bin, '-in', f'{outfile_tmp}.fa', '-out', f'{outfile_tmp}.out'],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    stdout, stderr = result.communicate()
    
    log_file.write(f'#sCas_scan running: {datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}\n')
    log_file.write(f"{fasta_file_path} --flanking_length {flanking_length} --genome_size: {genome_size} --cas_size: {cas_size} \n")
    log_file.write(f"{stdout.decode('utf-8')}\n")
    log_file.write(f"{stderr.decode('utf-8')}\n\n")
    return outfile_tmp

def run_in_threads(exec_bin, outfile_tmps, log_file, fasta_file_path, flanking_length, genome_size, cas_size):

	with concurrent.futures.ThreadPoolExecutor() as executor:

		futures = {
			executor.submit(
				process_file, exec_bin, outfile_tmp, log_file, fasta_file_path, flanking_length, genome_size, cas_size
			): outfile_tmp for outfile_tmp in outfile_tmps
		}
		

		for future in concurrent.futures.as_completed(futures):
			outfile_tmp = futures[future]
			print(f" >>Finished processing {outfile_tmp}")


def reverse_complement(sequence):
    complement = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C', 'U': 'A'}

    return ''.join(complement[base] for base in reversed(sequence))


def sCas_scan(fasta_file_path, flanking_length=12000,genome_size=3000,cas_size=400,pilercr_out='pilercr',min_prodigal=500000,cas_max=1000,motif = "RxxxxH"):
	if cas_max < cas_size:
		cas_max=cas_size+200
	

	prodigal_train_set = set()  
	pilercr_outs = defaultdict(list)  
 
	out_index=1  
	pilercr_out=f'{pilercr_out}_{genome_size}'
	# flanking_length=flanking_length*1000
	print(current_time)
	# print(flanking_length)
	print(f"\033[92mcrispr scanning...\033[0m")
	dest_directory=f'CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}_running'
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)		
	# shutil.copy(filename, dest_directory) pilercr   500000000
	os.chdir(dest_directory)

	
	input_fasta=f'../{fasta_file_path}'
	# output_fasta=f'{out_index}_{pilercr_out}.fa'
	sseq_origname = defaultdict(str) 
	sseq_rename=0
	
	fasta_online = defaultdict(str)  #
	fasta_erpin = defaultdict(str)  #
	fasta_erpin_in = defaultdict(str)  #
	with open(input_fasta, "r") as infile:
		sequence = ""
		header = ""
		for line in infile:
			line = line.strip()
			if line.startswith(">"):
				if len(sequence) > genome_size:
					# outfile.write(f"{header}\n{sequence}\n")  
					sseq_rename+=1
					sseq_origname[f'sseq_{sseq_rename}']=header[1:]
					fasta_online[f'sseq_{sseq_rename}']=sequence
					prodigal_train_set.add(f'sseq_{sseq_rename}')
				
				header = line
				sequence = ""
			else:
				sequence += line
		if len(sequence) > genome_size:
			# outfile.write(f"{header}\n{sequence}\n")
			sseq_rename+=1
			sseq_origname[f'sseq_{sseq_rename}']=header[1:]
			fasta_online[f'sseq_{sseq_rename}']=sequence
			prodigal_train_set.add(f'sseq_{sseq_rename}')
 
 # , open(output_fasta, "w") as outfile
	sum_bases=0
	out_index_tmp=0
	outfile_tmps = set()  #
	outfile_tmp=f'{out_index}_{pilercr_out}_{out_index_tmp}'
	outfile_tmps.add(outfile_tmp)
	for scaffold_id in fasta_online:
		sum_bases+=len(fasta_online[scaffold_id])
		if sum_bases>550000000:
		# if sum_bases>5500000:
			sum_bases=0
			out_index_tmp+=1
			outfile_tmp=f'{out_index}_{pilercr_out}_{out_index_tmp}'
			outfile_tmps.add(outfile_tmp)
		with open(f'{outfile_tmp}.fa', "a") as outfile:
			outfile.write(f">{scaffold_id}\n{fasta_online[scaffold_id]}\n")
			
			
	log_file=f'0_{fasta_file_path.split(".")[0]}_{current_time}.running.log'
	log_file=open(log_file, 'w')
	exec_bin = 'pilercr'

	run_in_threads(exec_bin, outfile_tmps, log_file, fasta_file_path, flanking_length, genome_size, cas_size)

	print(f"\033[92mcrispr done...\033[0m")
	outfile_tmp_union=open(f'{out_index}_{pilercr_out}_union.out','w')
	for outfile_tmp in outfile_tmps:
		pilercr_is=False
		with open(f'{outfile_tmp}.out', "r") as infile:
			for line in infile:
				outfile_tmp_union.write(f'{line}\n')
				if re.match(r'SUMMARY\s+BY\s+SIMILARITY',line.strip()):
					pilercr_is=True
					# print(line)
				if re.match(r'SUMMARY\s+BY\s+POSITION',line.strip()):
					break
				if pilercr_is:
					lines=re.split(r"\s+",line.strip())
					if lines[0].isdigit():
						# print(lines[1])
						if lines[1] in prodigal_train_set:
							prodigal_train_set.remove(lines[1])
							# print(lines[1])
						
						pilercr_in=f'{lines[1]}_{lines[2]}_{lines[3]}'
						fasta_erpin_in[pilercr_in]=fasta_online[lines[1]][int(lines[2])-1:int(lines[3])+int(lines[2])]
						lines[3]=int(lines[2])+int(lines[3])+flanking_length
						lines[2]=max(int(lines[2])-flanking_length-1,0)
						lines[8]=re.sub(r'[^ATCG]', '', lines[8], flags=re.IGNORECASE)
						if lines[7]=='-':
							# print(f'old {lines}')
							lines[8]=reverse_complement(lines[8])
							# print(f'new {lines}')
						pilercr_outs[pilercr_in]=lines

	# print(pilercr_outs)	
	# print(prodigal_train_set)	
	outfile_tmp_union.close()
	
	with open(f'{out_index+2}_{pilercr_out}_prodigal.fa', "w") as outfile:
		for pilercr_in in pilercr_outs:
			sequence_in=fasta_online[pilercr_outs[pilercr_in][1]][pilercr_outs[pilercr_in][2]:pilercr_outs[pilercr_in][3]]
			out_index+=len(sequence_in)
			outfile.write(f">{pilercr_in}\n{sequence_in}\n")
			fasta_erpin[pilercr_in]=fasta_online[pilercr_outs[pilercr_in][1]].replace(fasta_erpin_in[pilercr_in], '-' * len(fasta_erpin_in[pilercr_in]))
		# print(f'out_index {out_index}')
		if out_index<min_prodigal:
			# print(list(prodigal_train_set)[0:max((min_prodigal-out_index)//3000,1)])
			for scaffold_in in list(prodigal_train_set)[0:max((min_prodigal-out_index)//3000,1)]:
				outfile.write(f">{scaffold_in}\n{fasta_online[scaffold_in]}\n")	
	fasta_online.clear()	

	if out_index<20000:
		print(f"\033[91mError: {out_index}bp Too short for protein prediction. The minimum required genome length is 20000 bp.\033[0m")
		return 0
	
	out_index=1  	
	
	print(f"\033[92mprodigal running...\033[0m")
	# prodigal -c  -a  temp.pep   -i  temp  -p single  -f gff  -o  temp.gff pep
	exec_bin = 'prodigal'
	result = subprocess.Popen(
		[exec_bin, '-c', '-a', f'{out_index+3}_{pilercr_out}.pep', '-i',f'{out_index+2}_{pilercr_out}_prodigal.fa', '-p', 'single', '-f', 'gff', '-o', f'{pilercr_out}.gff'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
	)
	# log_file=f'0_{fasta_file_path.split(".")[0]}_{current_time}.running.log'
	# log_file=open(log_file, 'a')
	stdout, stderr = result.communicate()
	log_file.write(f">>>prodigal running...<<<\n\n") 
	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n")
	print(f"\033[92mprodigal done...\033[0m")
	
	
	print(f"\033[92mhmmscan running...\033[0m")
	# prodigal -c  -a  temp.pep   -i  temp  -p single  -f gff  -o  temp.gff pep
	exec_bin = 'hmmscan'
	result = subprocess.Popen(
		[exec_bin, '-E', '1e-5', '--tblout', f'{out_index+3}_{pilercr_out}.hmmscan',os.path.dirname(os.path.abspath(__file__))+'/hmm_cas/cas_db_all.hmm', f'{out_index+3}_{pilercr_out}.pep'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
	)
	# log_file=f'0_{fasta_file_path.split(".")[0]}_{current_time}.running.log'
	# log_file=open(log_file, 'a')
	stdout, stderr = result.communicate()
	log_file.write(f">>>prodigal running...<<<\n\n") 
	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n")
	print(f"\033[92mhmmscan done...\033[0m")
	# hmmscan  --tblout t13.txt  -E 1e-5   hmm_cas/cas_db_all.hmm t13.fasta
	print(f"\033[92mparsing and visualization...\033[0m")
	# fasta_online = defaultdict(str)  #
	protein_strands = defaultdict(str)  #
	hmm_rs_hit=set()
	with open(f'{out_index+3}_{pilercr_out}.pep', "r") as infile:
		sequence = ""
		header = ""
		for line in infile:
			line = line.strip()
			if line.startswith(">"):
				if len(sequence) > cas_size and len(sequence) <= cas_max:
					headers=re.split(r'\s+',header[1:])
					headerss=re.split(r'_',headers[0])
					# fasta_online[re.sub(r'_\d+$', '', headers[0])]=sequence 2 4
					# print(headers)        max(int(headerss[-3])-flanking_length-1,0)
					protein_strand='+'
					if headers[6]=='-1':
						protein_strand='-'
					
					pilercr_in=re.sub(r'_\d+$', '', headers[0])
					if pilercr_in in pilercr_outs:
						# print(f'{len(headerss)} {max(int(headerss[-3])-flanking_length-1,0)} {headerss[-3]} {headers[0]} {protein_strand} {re.sub(r'_\d+$', '', headers[0])}')
						# print(headers)   filter_protein_sequence(scaffold_fasta)
						prefix_padding=max(int(headerss[-3])-flanking_length-1,0)
						fasta_online[headers[0]]=filter_protein_sequence(sequence)
						protein_strands[headers[0]]=f'{protein_strand},{int(headers[2])+prefix_padding},{int(headers[4])+prefix_padding}'
						
						
				header = line
				sequence = ""
			else:
				sequence += line
		if len(sequence) > cas_size and len(sequence) <= cas_max:
			# headers=re.split(r'\s+',header[1:])
			# # fasta_online[re.sub(r'_\d+$', '', headers[0])]=sequence			
			# fasta_online[headers[0]]=sequence			
			headers=re.split(r'\s+',header[1:])
			headerss=re.split(r'_',headers[0])
			# fasta_online[re.sub(r'_\d+$', '', headers[0])]=sequence 2 4
			# print(headers)        max(int(headerss[-3])-flanking_length-1,0)
			protein_strand='+'
			if headers[6]=='-1':
				protein_strand='-'
			pilercr_in=re.sub(r'_\d+$', '', headers[0])
			if pilercr_in in pilercr_outs:
				# print(f'{len(headerss)} {max(int(headerss[-3])-flanking_length-1,0)} {headerss[-3]} {headers[0]} {protein_strand} {re.sub(r'_\d+$', '', headers[0])}')
				# print(headers)
				prefix_padding=max(int(headerss[-3])-flanking_length-1,0)
				fasta_online[headers[0]]=filter_protein_sequence(sequence)
				protein_strands[headers[0]]=f'{protein_strand},{int(headers[2])+prefix_padding},{int(headers[4])+prefix_padding}'
				
	
	sCas_scans = defaultdict(str) #last protein index
	sCas_hmscan = defaultdict(str) #last protein index

	with open(f'{out_index+3}_{pilercr_out}.hmmscan', "r") as infile:
		for line in infile:
			lines=re.split(r'\s+',line.strip())
			if len(lines)>3:
				sCas_hmscan[lines[2]]+=f'{lines[0]};'

	#print(sCas_hmscan)
	#dr_of=open(f'DR_{fasta_file_path.split(".")[0]}_{current_time}.fa', 'w')
	outfile_tmps = set()  #
	dr_seqs = set()  #
	out_index_tmp=0
	
	for scaffold_id in fasta_online:
		# print(scaffold_id)
		# print(sCas_hmscan[scaffold_id])
		scaffold_id2=re.sub(r'_\d+$', '', scaffold_id)  #protein id only
		if scaffold_id2 not in pilercr_outs:
			continue
		# print(f'{scaffold_id} {scaffold_id2} {pilercr_outs[scaffold_id2]}') sseq_origname[scaffold_id2] sseq_origname[scaffold_id2]
		pilercr_outs[scaffold_id2][0]=scaffold_id
		
		sCas_scans_tmp=pilercr_outs[scaffold_id2].copy()
		sCas_scans_tmp.append(scaffold_id)		
		sCas_scans_tmp.append(sseq_origname[re.sub(r'_\d+_\d+$', '', scaffold_id2)])		
		# print(pilercr_outs[scaffold_id2])
		# print(sCas_scans_tmp) 
		# print(scaffold_id) 
		# print(scaffold_id2) 
		# print(re.sub(r'_\d+_\d+_\d+$', '', scaffold_id)) 
		#dr_of.write(f'>{sCas_scans_tmp[10]}\n{sCas_scans_tmp[8]}\n')
		if sCas_scans_tmp[8] not in dr_seqs:
			dr_seqs.add(sCas_scans_tmp[8])
			outfile_tmps.add(f'DR_{fasta_file_path.split(".")[0]}_{current_time}_{out_index_tmp//60}')
			with open(f'DR_{fasta_file_path.split(".")[0]}_{current_time}_{out_index_tmp//60}.fa', "a") as dr_of:
				dr_of.write(f'>{sCas_scans_tmp[10]}\n{sCas_scans_tmp[8]}\n')
			out_index_tmp+=1
		

		if fasta_online[scaffold_id] in sCas_scans:
			for sCas_inner in range(0,len(sCas_scans[fasta_online[scaffold_id]])):
				sCas_scans[fasta_online[scaffold_id]][sCas_inner]=f'{str(sCas_scans[fasta_online[scaffold_id]][sCas_inner])};{str(sCas_scans_tmp[sCas_inner])}'	
		else:
			sCas_scans[fasta_online[scaffold_id]]=sCas_scans_tmp
		
		hmm_rs=None
		if scaffold_id in sCas_hmscan:
			hmm_rs = sCas_hmscan[scaffold_id]
			hmm_rs_hit.add(fasta_online[scaffold_id])
		# hmm_rs = sCas_hmscan[scaffold_id] if scaffold_id in sCas_hmscan else None
		protein_strands[fasta_online[scaffold_id]]=f'{protein_strands[scaffold_id]},{hmm_rs}'
		# protein_strands
	#dr_of.close()	
	fasta_online.clear()
	for outfile_tmp in outfile_tmps:
		draw_rna_structure(f'{outfile_tmp}.fa',row_sum=4,is_show=False)
		shutil.copy(f'{outfile_tmp}_RNA_Struct.pdf', f'../RNA_Struct_DR_{outfile_tmp}.pdf')
	
	
	# draw_rna_structure(f'DR_{fasta_file_path.split(".")[0]}_{current_time}.fa',row_sum=4,is_show=False)
	os.chdir('..')
	# shutil.copy(f'{dest_directory}/DR_{fasta_file_path.split(".")[0]}_{current_time}_RNA_Struct.pdf', f'RNA_Struct_DR_{fasta_file_path.split(".")[0]}_{current_time}.pdf')
	
	crispr_locs = defaultdict(set)  #
	crispr_locs_strands = defaultdict(str)  #
	protein_locs = defaultdict(set)  #
	protein_locs_strands = defaultdict(str)  #
	# print(pilercr_outs) sseq_origname[f'sseq_{sseq_rename}']
	sCas_index=0
	with open(f'CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}.csv', "w") as outfile, open(f'{dest_directory}/CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}.fasta', "w") as outfile2, open(f'{dest_directory}/CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}_hmm_cas.fasta', "w") as outfile3, open(f'{dest_directory}/CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}_crispr_mask.fasta', "w") as outfile4:
		outfile.write(f'sCas,Sequence,Len_Sequence,strand_Cas,Start_Cas,End_Cas,hmm_cas,Scaffold_cripr_info,Scaffold,Start_crispr_flanking,End_crispr_flanking,Copies,Len_Repeat,Len_Spacer,Strand_Repeat,Seq_Repeat,pep_id,orig_Scaffold_name,MOTIF: {motif},motif_count\n')
		for scaffold_fasta in sCas_scans:
			sCas_index+=1
			# pilercr_outss=pilercr_outs[scaffold_id][1:]	
			# print(",".join(pilercr_outss))
			# string_data = ",".join(map(str, pilercr_outss))
			# outfile.write(f'{scaffold_id},{fasta_online[scaffold_id]},{",".join(map(str, pilercr_outss))}\n')
			outfile2.write(f'>sCas_{sCas_index} {sCas_scans[scaffold_fasta][-3]}\n{scaffold_fasta}\n')
			if scaffold_fasta in hmm_rs_hit:
				outfile3.write(f">sCas_{sCas_index} {sCas_scans[scaffold_fasta][-1]} {protein_strands[scaffold_fasta]} {re.sub(r'T', 'U', sCas_scans[scaffold_fasta][-3], flags=re.IGNORECASE)}\n{scaffold_fasta}\n")
			outfile.write(f'sCas_{sCas_index},{scaffold_fasta},{len(scaffold_fasta)},{protein_strands[scaffold_fasta]},{",".join(map(str, sCas_scans[scaffold_fasta]))},{find_motif_in_sequence(scaffold_fasta, motif)}\n')
			# print(sCas_scans[scaffold_fasta])
			
			crispr_infos,scaffold_id,crispr_info_strand=abs_criprs(sCas_scans[scaffold_fasta][0], sCas_scans[scaffold_fasta][1], sCas_scans[scaffold_fasta][7])
			# print(crispr_info_strand)
			# print(scaffold_id)
			# print(protein_strands[scaffold_fasta].split(",")[1]) 
			crispr_locs[scaffold_id]=crispr_locs[scaffold_id].union(crispr_infos)
			# crispr_locs_strands[scaffold_id]=crispr_info_strand
			if not crispr_locs_strands[scaffold_id]:
				crispr_locs_strands[scaffold_id]={}
			crispr_locs_strands[scaffold_id].update(crispr_info_strand)


			protein_stinfo=protein_strands[scaffold_fasta].split(",")
			protein_locs[scaffold_id].add(protein_stinfo[1])
			protein_locs_strands[protein_stinfo[1]]=protein_stinfo[0]

			outfile4.write(f">sCas_{sCas_index} {sCas_scans[scaffold_fasta][-1]} {protein_strands[scaffold_fasta]} {sCas_scans[scaffold_fasta][-3]}\n{fasta_erpin[re.sub(r'_\d+$', '', sCas_scans[scaffold_fasta][0].split(';')[0])]}\n")
		
			

		

	log_file.write(f'\n#sCas_scan done: {datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}\n\n')
	log_file.close()

	num_rows = len(crispr_locs)
	if num_rows>0:
		num_rows_per_page=min(60,num_rows)
		
		num_pages = (num_rows + num_rows_per_page - 1) // num_rows_per_page  

		for page in range(num_pages):
			# print(page)
			figsize_height=num_rows_per_page
			if page==(num_pages-1):
				figsize_height=num_rows-num_rows_per_page*page
				# print(num_rows-num_rows_per_page*page)
			
			
			fig, axs = plt.subplots(min(num_rows_per_page, num_rows - page * num_rows_per_page), 1, figsize=(6, 1.8 * figsize_height))
			
			for i in range(min(num_rows_per_page, num_rows - page * num_rows_per_page)):
				scaffold_id = list(crispr_locs.keys())[page * num_rows_per_page + i]  # 
				rectangle_positions = sorted([int(loc) for loc in list(protein_locs[scaffold_id])])
				rectangle_positions_labs = [f'{p_loc}_{protein_locs_strands[str(p_loc)]}' for p_loc in rectangle_positions]
				
				crispr_positions = sorted([int(loc) for loc in list(crispr_locs[scaffold_id])])
				crispr_labs = [f'{p_loc}_{crispr_locs_strands[scaffold_id][str(p_loc)]}' for p_loc in crispr_positions]
				ax = axs[i] if num_rows > 1 else axs
				ax.set_facecolor('#f0f0f0')
				ax.set_title(f'{i + 1 + page * num_rows_per_page}: {scaffold_id} {sseq_origname[scaffold_id]}', fontsize=10, loc='left', y=0.75)
				ax.axis('equal')
				draw_crispr(ax, crispr_positions, crispr_labs, rectangle_positions, rectangle_positions_labs)
				ax.axis('off')
				ax.grid(False)

			plt.tight_layout()
			pdf_opt = f'sCas_scan_{datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}_page_{page + 1}.pdf'  # 
			plt.savefig(pdf_opt, format='pdf')
			plt.close(fig)  # 
		
		
	# plt.show()
	print(f"\033[92mDone...\033[0m {num_rows}")


def draw_rna_structure(fasta_file_path, row_sum=3, size_base=5, dpi=150,bin_exc='lib_exc',is_show=True):
	def extract_lines(filename):
		with open(filename, 'r') as file:
			lines = file.readlines()
		structure = re.split(r'\s+', lines[2].strip())[0]
		free_energy = lines[3].strip()   
		return structure, free_energy

	def run_rnafold(sequence):
		input_file = 'temp_sequence.fasta'
		with open(input_file, 'w') as f:
			f.write(f'>sequence\n{sequence}\n')

		output_file = f'{input_file}.RNAfold.tmp'
		
		exc_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_exc}/RNAfold'
		
		command = [exc_script, '-p0', f'-o{output_file}', input_file]

		try:
			subprocess.run(command, check=True)
			structure, free_energy = extract_lines(output_file)
			os.remove(output_file)
			os.remove(input_file)   
			os.remove("sequence_ss.ps")   
			return structure, free_energy
		except subprocess.CalledProcessError as e:
			print(f'Error occurred while running RNAfold: {e}')
			return 0

	 
	def read_fasta(file_path):
		labs = []
		seqs = []
		with open(file_path, 'r') as f:
			seq = ""
			for line in f:
				line = line.strip()
				if line.startswith(">"):
					if seq:   
						seqs.append(seq)
						seq = ""
					labs.append(line[1:])  
				else:
					seq += line   
			if seq:  
				seqs.append(seq)
		return labs, seqs

	labs, seqs = read_fasta(fasta_file_path)
	opt_name = f"{os.path.splitext(fasta_file_path)[0]}_RNA_Struct"
	units_number = len(labs)

	col_sum = len(labs) // row_sum   
	if len(labs) % row_sum:
		col_sum += 1
	
	max_sizes=[]
	
		
	for seq in seqs:
		fig, temp_ax = plt.subplots()
		structure, free_energy = run_rnafold(seq)
		max_size=draw_struct(seq, structure, ax=temp_ax)
		plt.close(fig)
		max_sizes.append(max_size)	
		
	max_sizes_base=max(max_sizes)
 
	i_size=0
	for lab_id in range(0, len(labs), units_number):
		 
		if row_sum == 1:
			fig, axes = plt.subplots(col_sum, 1, figsize=(size_base * 2, size_base * 2 * col_sum))
			axes = [axes] if col_sum == 1 else axes
		else:
			fig, axes = plt.subplots(col_sum, row_sum, figsize=(size_base * 2 * row_sum, size_base * 2 * col_sum))
		
		for i, ax in enumerate(axes.flat if row_sum > 1 else axes):
			
			lab_i = i + lab_id
			if lab_i + 1 > units_number:
				break
			# print(str(lab_i + 1) + "\t" + seqs[lab_i] + "\t" + labs[lab_i])
			is_show and print(f'{lab_i + 1} {seqs[lab_i]} {labs[lab_i]}')
			
			seq = seqs[lab_i]
			structure, free_energy = run_rnafold(seq)
			ax.set_title(labs[lab_i] + '\n' + seq + '\n' + free_energy,fontsize=size_base * row_sum)

			
			scale_factor = max_sizes[i_size]/max_sizes_base  
			
			row_index = i // row_sum
			col_index = i % row_sum
			
			left = 0.0 + col_index * (0.8 / row_sum)  
			bottom = 0.0 + (col_sum - 1 - row_index) * (1 / col_sum)
			
			ax.set_position([left, bottom, 0.9 * scale_factor / row_sum, 0.9 * scale_factor / col_sum])
		
			
			draw_struct(seq, structure, ax=ax)
			i_size+=1
			# max_sizes.append(max_size) max_sizes_base

			
		if i==units_number:
			i-=1			
 
		for j in range(i+1, len(axes.flat if row_sum > 1 else axes)):
			fig.delaxes(axes.flat[j] if row_sum > 1 else axes[j])
			# print(f'delaxes: {j}')
		plt.savefig(f'{opt_name}.pdf', dpi=dpi, bbox_inches='tight')
def run_protein_msa(ipt_query,pt='',msa='',bin_exc='lib_exc',tree_width=300):
	opt = ipt_query
	tree_ipt=pt
	msa_ipt=msa

	if pt:

		print('Skip multiple sequence alignment (MSA) and phylogenetic tree drawing...')
		
	else:
		opt = os.path.splitext(ipt_query)[0]	
		# output_fasta='{}.checked.fasta'.format(opt)
		output_fasta=f'{opt}.checked.fasta'
		output_fasta2=f'{opt}.msa'
		tree_ipt=f'{opt}.muscle.tree'
		msa_ipt=f'{opt}.muscle.fas'
		log_file=open(f'{opt}.ms.log', 'w')		
		print(f"\033[92mCheck for duplicates in FASTA headers and replace invalid characters....\033[0m")
		
		fasta_headers = defaultdict(int)  #

		with open(ipt_query, "r") as infile, open(output_fasta, "w") as outfile, open(output_fasta2, "w") as outfile2:
			sequence = ""
			header = ""
			outfile2.write(f"(")
			for line in infile:
				line = line.strip()
				if line.startswith(">"):
					if sequence:
						outfile.write(f">{header}\n{filter_protein_sequence(sequence)}\n")
						outfile2.write(f"{header}:0,")
					

					header_orig = re.sub(r'\W+', '_', line[1:])
					header = header_orig
					
					if header_orig in fasta_headers:
						header=f'{header_orig}_{fasta_headers[header_orig]}'
					fasta_headers[header_orig]+=1
						
						
					 
					sequence = ""	
				else:
					sequence += line
			if sequence:
				outfile.write(f">{header}\n{filter_protein_sequence(sequence)}\n")
				outfile2.write(f"{header}:0);")

		print('...Begin to run muscle...')
		exc_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_exc}/muscle'
		result = subprocess.Popen([exc_script, '-in', output_fasta, '-out', msa_ipt],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  
		stdout, stderr = result.communicate()
		
		log_file.write(f'#protein_msa running: {datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}\n')
		log_file.write(f">>>muscle running...<<<\n\n") 
		log_file.write(f"{stdout.decode('utf-8')}")  
		log_file.write(f"{stderr.decode('utf-8')}\n\n")

 
		print('...Begin to run FastTree...')
		exc_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_exc}/FastTree'
		with open(tree_ipt, 'w') as outfile:
			result=subprocess.Popen([exc_script, msa_ipt],stdout=outfile,stderr=subprocess.PIPE)
			stdout, stderr = result.communicate()
			log_file.write(f">>>FastTree running...<<<\n\n")   
			log_file.write(f"{stderr.decode('utf-8')}\n\n")

		# exc_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_exc}/ete3'
		# subprocess.call([exc_script, 'view', '-t', '{}.muscle.tree'.format(opt), '--alg', '{}.muscle.fas'.format(opt), '--alg_type', 'compactseq', '-i', 'msa_ete3_{}.pdf'.format(opt)])
		
		log_file.close()


	print('...Generating PDF with ete3...')

	args = argparse.Namespace(
		src_trees=[output_fasta2],
		src_tree_list=None,
		src_tree_attr='name',
		src_attr_parser=None,
		src_newick_format=0,
		output=None,
		verbosity=2,
		face=None,
		mode='r',
		image=f'{opt}_MSA.pdf',
		text_mode=False,
		show_attributes=None,
		width=0,
		height=0,
		resolution=300,
		size_units='px',
		branch_separation=3,
		show_support=False,
		show_branch_length=False,
		force_topology=False,
		hide_leaf_names=False,
		show_internal_names=False,
		tree_width=tree_width,
		color_by_rank=None,
		raxml=False,
		alg=msa_ipt,
		alg_type='compactseq',
		alg_format='fasta',
		as_ncbi=False,
		heatmap=None,
		profile=None,
		bubbles=None,
		func=ete_view.run   
	)
	 
	args.func(args)
	
	os.remove(output_fasta2)	

	args = argparse.Namespace(
		src_trees=[tree_ipt],
		src_tree_list=None,
		src_tree_attr='name',
		src_attr_parser=None,
		src_newick_format=0,
		output=None,
		verbosity=2,
		face=None,
		mode='r',
		image=f'{opt}_MSA_TREE.pdf',
		text_mode=False,
		show_attributes=None,
		width=0,
		height=0,
		resolution=300,
		size_units='px',
		branch_separation=3,
		show_support=False,
		show_branch_length=False,
		force_topology=False,
		hide_leaf_names=False,
		show_internal_names=False,
		tree_width=tree_width,
		color_by_rank=None,
		raxml=False,
		alg=msa_ipt,
		alg_type='compactseq',
		alg_format='fasta',
		as_ncbi=False,
		heatmap=None,
		profile=None,
		bubbles=None,
		func=ete_view.run   
	)
	 
	args.func(args)
	print(f"\033[92mDone....\033[0m")
  
  
  

def extract_zscore(filepath):
	if not os.path.exists(filepath):
		return 0  # ???t2?¡ä??¨²¨º¡À¡¤¦Ì?? 0.0

	z_score = 0  # ??¨¨? Z-score ?a 0.0

	# ?¡§¨°??y?¨°¡À¨ª¡ä?¨º?¨¤¡ä?£¤?? "# No:" ?a¨ª¡¤¦Ì?DD
	no_pattern = re.compile(r"^#\s*No:")

	with open(filepath, 'r') as f:
		line = f.readline()  # ?¨¢¨¨?¦Ì¨²¨°?DD
		while line:  # ?eDD?¨¢¨¨?¡ê??¡À¦Ì????t???2
			line = line.strip()  # ¨¨£¤3y¨º¡Á?2????
			# 2¨¦?¨°¡¤?o??y?¨°¡À¨ª¡ä?¨º?¦Ì?DD
			if no_pattern.match(line):
				line = f.readline()
				try:
					# ¨¬¨¢¨¨? Z-score¡ê¡§?¨´¨¦¨¨ Z-score ??¨®¨²¦Ì¨² 3 ¨¢D¡ê?
					columns = line.split()
					z_score = float(columns[2])  # Z-score ?¨²¦Ì¨² 3 ¨¢D¡ê¡§?¨¦¨°?¦Ì¡Â???¡Â¨°y¡ê?
					return z_score
				except Exception as e:
					# print(f"Error parsing Z-score: {filepath}")
					return 0 # ¨¨?1??a??¨º¡ì¡ã¨¹¡ê?¡¤¦Ì????¨¨??¦Ì 0.0
			
			# ?¨¬D??¨¢¨¨???¨°?DD
			line = f.readline()

	return z_score  # ¨¨?1???¨®D?¨°¦Ì? Z-score¡ê??¨°¡¤¦Ì?? 0.0




def compute_zscore_for_pair(pdb1, pdb2, pdb_folder, perl_script, current_time, pair_name):
	pair_dir = pair_name
	os.makedirs(pair_dir, exist_ok=True)

	src1 = os.path.join(pdb_folder, pdb1)
	src2 = os.path.join(pdb_folder, pdb2)
	shutil.copy(src1, os.path.join(pair_dir, pdb1))
	shutil.copy(src2, os.path.join(pair_dir, pdb2))

	link_pdbfile1 = os.path.join(pair_dir, 'pdbfile1')
	link_pdbfile2 = os.path.join(pair_dir, 'pdbfile2')
	os.symlink(os.path.abspath(os.path.join(pair_dir, pdb1)), link_pdbfile1)
	os.symlink(os.path.abspath(os.path.join(pair_dir, pdb2)), link_pdbfile2)

	result = subprocess.Popen(
		['perl', perl_script, '--pdbfile1', 'pdbfile1', '--pdbfile2', 'pdbfile2',
		 '--dat1', '.', '--dat2', '.', '--title', pair_name,
		 '--outfmt', 'summary,alignments,equivalences,transrot', '--clean'],
		stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=pair_name
	)
	stdout, stderr = result.communicate()

	log_path = os.path.join(pair_dir, f'pdb2pdb_{current_time}.run.log')
	with open(log_path, 'w') as log_file:
		log_file.write(f">>>{pair_name}<<<\n\n")
		log_file.write(stdout.decode('utf-8'))
		log_file.write(stderr.decode('utf-8'))



	z_score=0
	mol1A=find_result_txt(pair_dir)
	if mol1A:
		result_file = os.path.join(pair_dir, mol1A)
		z_score = extract_zscore(result_file)
		
	return pdb1, pdb2, z_score


# Function to compute the DALI matrix
def compute_dali_matrix(pdb_folder,max_threads=max_threads,width=800,inner_width=28,inner_height=8, bin_dali='lib_exc',linkage_method='average'):
	# Get the current time to create unique directories
	# current_time = time.strftime("%Y-%m-%d_%H-%M-%S")
	opt_name=f"{os.path.basename(pdb_folder)}_StructMatrix_{current_time}"
	parent_dir = os.path.abspath(os.path.join(pdb_folder, os.pardir))
	dest_directory = os.path.join(parent_dir, opt_name)
	os.makedirs(dest_directory, exist_ok=True)
	os.chdir(dest_directory)

	pdb_folder = os.path.abspath(os.path.join('..', os.path.basename(pdb_folder)))
	# print(pdb_folder)
	pdb_files = [f for f in os.listdir(pdb_folder) if f.endswith('.pdb')]

	perl_script = os.path.dirname(os.path.abspath(__file__)) + f'/{bin_dali}/dali.pl'

	zscore_matrix = pd.DataFrame(index=pdb_files, columns=pdb_files)

	# Use ThreadPoolExecutor for multi-threading
	with ThreadPoolExecutor() as executor:
		futures = []
		for i in range(len(pdb_files)):
			for j in range(i + 1, len(pdb_files)):
				pdb1 = pdb_files[i]
				pdb2 = pdb_files[j]
				pair_name = f"{os.path.splitext(pdb1)[0]}_vs_{os.path.splitext(pdb2)[0]}"
				futures.append(executor.submit(compute_zscore_for_pair, pdb1, pdb2, pdb_folder, perl_script, current_time, pair_name))

		# Collect results as they finish
		for future in futures:
			pdb1, pdb2, z_score = future.result()
 		
			if z_score < 0.01:
				print(f"[WARN] Z-score < 0.01 for: {pdb1} vs {pdb2}, auto-set to 0.01 for visualization compatibility")
				z_score = 0.01 
	
			zscore_matrix.loc[pdb1, pdb2] = z_score
			zscore_matrix.loc[pdb2, pdb1] = z_score

	np.fill_diagonal(zscore_matrix.values, 0.0)
	zscore_matrix = zscore_matrix.astype(float).fillna(0.0)
	zscore_matrix.columns = zscore_matrix.columns.str.split('.').str[0]  # For columns
	zscore_matrix.index= zscore_matrix.index.str.split('.').str[0]  # For columns

	zscore_matrix.to_csv(f"{dest_directory}/{os.path.basename(pdb_folder)}_Zscore_Matrix.csv")

	# Check the number of pdb files and labels new_name.split('.')[0]
	# print(f"Number of pdb files: {len(pdb_files)}")
	# print(f"Number of labels: {len(zscore_matrix.columns)}")

	# Hierarchical clustering
	dist_matrix = 1 / zscore_matrix.replace(0, np.nan).fillna(1e-5).values
	np.fill_diagonal(dist_matrix, 0)
	dist_matrix = squareform(dist_matrix)

	Z = linkage(dist_matrix, method=linkage_method)

	Z[:, 2] = Z[:, 2] / Z[:, 2].max()
	# Print Z shape for debugging
	# print(f"Z.shape[0]: {Z.shape[0]}")  # Check how many nodes were generated by clustering

	df_Z = pd.DataFrame(Z, columns=['Cluster 1', 'Cluster 2', 'Distance', 'Sample count'])
	df_Z.to_csv(f"{dest_directory}/clustered_tree.csv", index=False)
	# print(f"[OK] Clustered tree information saved to {dest_directory}/clustered_tree.csv")

	# Heatmap with hierarchical clustering
	dendro_result = dendrogram(Z, no_plot=True)  # ??¨¨? dendrogram ?¨¢1?


	zscore_matrix_reordered = zscore_matrix.iloc[dendro_result['leaves'], dendro_result['leaves']]
	# print(zscore_matrix_reordered)



	plt.figure(figsize=(10, 8))
	plt.imshow(zscore_matrix_reordered, cmap="viridis")
	plt.colorbar(label='Z-score')
	plt.xticks(ticks=np.arange(len(zscore_matrix_reordered.columns)), labels=zscore_matrix_reordered.columns, rotation=90, fontsize=6)

	plt.yticks(ticks=np.arange(len(zscore_matrix_reordered.index)), labels=zscore_matrix_reordered.index, fontsize=6)
	plt.title("Pairwise DALI Z-scores with Hierarchical Clustering")
	plt.tight_layout()
	plt.savefig(f"{dest_directory}/{os.path.basename(pdb_folder)}_heatmap_with_clustering.pdf")

	# Create dendrogram plot (visualize tree)
	plt.figure(figsize=(10, 8))
	dendrogram(Z, labels=zscore_matrix.index, orientation='top')
	plt.title("Hierarchical Clustering Dendrogram")
	plt.xlabel("Protein Index")
	plt.ylabel("Normalized Distance")
	plt.tight_layout()
	plt.savefig(f"{dest_directory}/{os.path.basename(pdb_folder)}_dendrogram.pdf")  # Save dendrogram as PDF
	plt.close()  # Close the plot to free memory

	# Use ETE3 to draw the tree
	labels = zscore_matrix.columns.tolist()
	# Ensure labels match the number of tree nodes
	# print(f"Adjusting number of labels to match the number of tree nodes: {Z.shape[0]}")
	# labels = labels[:Z.shape[0]]  # Truncate labels to match tree nodes count
	# # Ensure the labels are assigned only to leaf nodes
	# tree = Tree()
	# tree.populate(len(labels))  # Populate with the number of leaf nodes (labels)
	# # Get the correct order of labels from dendrogram's leaves
	leaf_order = dendro_result['leaves']  # Dendrogram returns the correct leaf order
	ete_tree_height=len(leaf_order)*50
	# # Reassign labels based on dendrogram leaf order
	# leaves = tree.get_leaves()
	# for i, node in enumerate(leaves):  # Iterate through the leaves
		# node.name = labels[leaf_order[i]]  # Assign the label to the leaf nodes
		
	tree = to_tree(Z, rd=False)
	newick_str = tree_to_newick(tree)

	# ts = TreeStyle()  show
	# # ts.force_topology = True  # ¡ã?¨ª???¦Ì¡À¡Á¡Â??¨°a?¨¢11¡ê?¡Á??¡¥?¨´?¨¨??¨º?2?¡ä? layout_fn
	# # ts.show_leaf_name = True                 # ??¨º?¨°??¨²¦Ì???¡Á?
	# # ts.show_branch_length = True            # ??¨º?¡¤??¡ì3¡è?¨¨¡ê¡§??¨°a¡ê?
	# # ts.show_branch_support = False          # 2???¨º?bootstrap?¡ì3??¨º
	# ts.scale = 100                          # ????o¨¢?¨°¡À¨¨¨¤y3?¡ê??¦Ì??¡ä¨®????¨º¨¨
	# ts.branch_vertical_margin = 20          # ????¨¦????¨²¦Ì?????¦Ì????¨¤¡ê¡§o¨¹1??¨¹¡ê?
	# ts.min_leaf_separation = 10             # ????¡Á?D?¨°??¨²¦Ì??¨¤¨¤?¡ê¡§¡À¨¹?a¨¬??¡¤¡ê?
	# ts.title.add_face(TextFace("Clustered Cas Protein Tree", fsize=12), column=0)

	ete_tree = Tree(newick_str)
	leaves = ete_tree.get_leaves()
	for i, node in enumerate(leaves):  # Iterate through the leaves
		node.name = labels[leaf_order[i]]  # Assign the label to the leaf nodes

	# ete_tree.render("generated_tree.pdf", w=1200, h=1200, dpi=300)
	# Render the tree and save it
	ete_tree.render(f"{dest_directory}/{os.path.basename(pdb_folder)}_clustered_tree.pdf", w=width, h=ete_tree_height, dpi=300)
	ete_tree.render(f"{dest_directory}/clustered_tree.png", w=width*3, h=ete_tree_height*3, dpi=300)

	ete_tree.write(format=1, outfile=f"{dest_directory}/{os.path.basename(pdb_folder)}_clustered_tree.tree")
	# print(f"[OK] Z-score matrix saved to {dest_directory}/Zscore_Matrix.csv")
	# print(f"[OK] Heatmap saved to {dest_directory}/heatmap_with_clustering.pdf")
	# print(f"[OK] Dendrogram saved to {dest_directory}/dendrogram.pdf")
	# print(f"[OK] Tree image saved to {dest_directory}/clustered_tree.png")
	# Example usage
	# Assuming zscore_matrix, Z, and dendro_result are already computed
	plot_combined_results(zscore_matrix, Z, dendro_result,width=inner_width,height=inner_height, dest_opt=opt_name)


def get_newick(node):
    """¦ÌY1¨¦??¨¨? Newick ??¨º?"""
    if node.is_leaf():
        return f"{node.id}"  # ¨°??¨²¦Ì???¡¤¦Ì???? id
    else:
        left = get_newick(node.get_left())  # ??¨¨?¡Á¨®¡Á¨®¨º¡Â¦Ì? Newick ??¨º?
        right = get_newick(node.get_right())  # ??¨¨?¨®¨°¡Á¨®¨º¡Â¦Ì? Newick ??¨º?
        return f"({left},{right}):{node.dist}"  # ¡¤¦Ì??¡ä?¨¤¡§o?¦Ì?¡Á¨®¨º¡Â?¨¢11¡ê?2¡é?¨®¨¦?¡¤??¡ì3¡è?¨¨

# ¨º1¨®?¦ÌY1¨¦??¨º??¡¥????¨º¡Â
def tree_to_newick(tree):
    # ¨¦¨²3¨¦¨º¡Â¦Ì? Newick ??¨º?¡ê?2¡é¨¨¡¤¡À¡ê??¨¬?¡À?¨¤¡§?e¨¤¡ä
    newick_str = get_newick(tree)
    return f"({newick_str});"  # ?¨´?¨²¦Ì?¨®|??¡ã¨¹o??¨²¡Á?¨ªa2?¦Ì?¨¤¡§o?¨¤?


def plot_combined_results(zscore_matrix, Z, dendro_result,width=28,height=8, dest_opt='dest_opt'):
    """
    Plot three results (Z-score Heatmap, Hierarchical Clustering Dendrogram, and ETE3 Tree visualization) together.
    
    Parameters:
    - zscore_matrix: The DataFrame containing Z-scores.
    - Z: The linkage matrix from hierarchical clustering.
    - dendro_result: The result of dendrogram computation (leaf order, etc.).
    - dest_directory: The directory where the output will be saved.
    """
    
    # Prepare the figure with 3 subplots (one row, three columns)
    fig, axes = plt.subplots(1, 3, figsize=(width,height))
    num_labels = len(zscore_matrix.columns)
    xtick_rotation = 45 if num_labels <= 20 else 90

    # 1. Z-score Heatmap with updated color palette (magma)
    zscore_matrix_reordered = zscore_matrix.iloc[dendro_result['leaves'], dendro_result['leaves']]
    cax = axes[0].imshow(zscore_matrix_reordered, cmap="magma")
    axes[0].set_title("Pairwise DALI Z-scores with Hierarchical Clustering", fontsize=12)
    axes[0].set_xticks(np.arange(len(zscore_matrix_reordered.columns)))
    axes[0].set_xticklabels(zscore_matrix_reordered.columns, rotation=90, fontsize=8)
    axes[0].set_yticks(np.arange(len(zscore_matrix_reordered.index)))
    axes[0].set_yticklabels(zscore_matrix_reordered.index, fontsize=8)
    
    # Adjust colorbar position
    cbar = fig.colorbar(cax, ax=axes[0], label='Z-score', fraction=0.02, pad=0.04)
    
    # 2. Dendrogram with customized color (use 'Blues' colormap for dendrogram)
    dendrogram(Z, ax=axes[1], labels=zscore_matrix.index, orientation='top')
    axes[1].set_title("Hierarchical Clustering Dendrogram", fontsize=12)
    axes[1].set_xlabel("Protein Index", fontsize=10)
    axes[1].set_ylabel("Normalized Distance", fontsize=10)
    axes[1].set_xticklabels(zscore_matrix_reordered.columns, rotation=xtick_rotation, fontsize=10)


    # 3. ETE3 Tree Visualization with customized style using NodeStyle
    # Render the tree and save as a separate file (TreeStyle object)

    # Now we add the image of the tree to our subplot
    img = plt.imread("clustered_tree.png")  # Read the image file
    axes[2].imshow(img)  # Display it in the third subplot
    axes[2].axis('off')  # Hide the axis for the tree

    # Save combined figure
    plt.tight_layout()
    plt.savefig(f"../{dest_opt}_combined_results.pdf")
    plt.close()
	
    # print(f"[OK] Combined result saved to {dest_directory}/combined_results.pdf")


def extract_haddock(input_dir, output_csv=None):

    records = []
    for root, dirs, files in os.walk(input_dir):
        if "4_seletopclusts_analysis" in root:
            for file in files:
                if file == "capri_clt.tsv":
                    file_path = os.path.join(root, file)
                    # print(f"Processing: {file_path}")
                    try:
                        df = pd.read_csv(file_path, sep="\t", comment="#")
                        if not df.empty:
                            top_model = df.iloc[0]  # Take the top-ranked model (Top1)

                            # Extract sCas ID
                            file_path_names = file_path.replace("\\", "/").split("/")
                            sCas_id = file_path_names[-5].replace("docking_", "")

                            records.append({
                                "sCas_ID": sCas_id,
                                "model": file_path_names[-4].replace("docking_", "").replace("run_", ""),
                                "HADDOCK_score": top_model.get("score", ""),
                                "i-RMSD": top_model.get("irmsd", ""),
                                "fnat": top_model.get("fnat", ""),
                                "cluster": top_model.get("cluster", "")
                            })
                    except Exception as e:
                        print(f"[Error] Cannot read {file_path}: {e}")

    # Save to CSV
    df = pd.DataFrame(records)

    if output_csv is None:
        base_name = os.path.basename(os.path.normpath(input_dir))
        output_csv = f"{base_name}_af3_docking_summary.csv"
    else:
        output_csv = f"{output_csv}_af3_docking_summary.csv"

    df.to_csv(output_csv, index=False)
    print(f"Extraction complete: {len(df)} records saved to {output_csv}")




def plot_combined_results1(zscore_matrix, Z, dendro_result, width=28, height=8, dest_opt='dest_opt'):
    """
    Plot Z-score heatmap, dendrogram, and ETE3 tree side-by-side.

    Parameters:
    - zscore_matrix: DataFrame of Z-scores.
    - Z: linkage matrix.
    - dendro_result: result of scipy dendrogram (dict).
    - width, height: figure size.
    - dest_opt: output filename prefix (without extension).
    """

    # ¡Á??¡¥?D?????¨¨¡êo¡À¨º?? ?¨¹ 20 ¨®? 90??, ¡¤??¨° 45??
    num_labels = len(zscore_matrix.columns)
    xtick_rotation = 90 if num_labels <= 20 else 45

    fig, axes = plt.subplots(1, 3, figsize=(width, height))

    # 1. Z-score heatmap
    zscore_matrix_reordered = zscore_matrix.iloc[dendro_result['leaves'], dendro_result['leaves']]
    cax = axes[0].imshow(zscore_matrix_reordered, cmap="magma")
    axes[0].set_title("Pairwise DALI Z-scores with Hierarchical Clustering", fontsize=12)
    axes[0].set_xticks(np.arange(num_labels))
    axes[0].set_xticklabels(zscore_matrix_reordered.columns, rotation=xtick_rotation, fontsize=8)
    axes[0].set_yticks(np.arange(num_labels))
    axes[0].set_yticklabels(zscore_matrix_reordered.index, fontsize=8)
    fig.colorbar(cax, ax=axes[0], label='Z-score', fraction=0.02, pad=0.04)

    # 2. Dendrogram
    dendrogram(Z, ax=axes[1], labels=zscore_matrix.index, orientation='top')
    axes[1].set_title("Hierarchical Clustering Dendrogram", fontsize=12)
    axes[1].set_xlabel("Protein Index", fontsize=10)
    axes[1].set_ylabel("Normalized Distance", fontsize=10)

    # 3. Tree (image)
    img = plt.imread("clustered_tree.png")
    axes[2].imshow(img)
    axes[2].axis('off')

    plt.tight_layout()
    plt.savefig(f"../{dest_opt}_combined_results.pdf")
    plt.close()








 
  
def main():
	parser = argparse.ArgumentParser(prog='casstructstream',description="A tool for designed for  Streamlining identification  of CRISPR-Cas systems")


	subparsers = parser.add_subparsers(dest="command", help="Subcommands")
	parser_cas = subparsers.add_parser("sCas", help="Streamlined Scanning of CRISPR-Cas Systems.")
	parser_cas.add_argument("assembly_file", help=" Input assembly file in FASTA format.")
	parser_cas.add_argument("--genome_size", type=int, default=3000, help="The minimum scaffold length for genome assembly. Scaffolds shorter than this value will be excluded from the assembly. [def. 3000]")
	parser_cas.add_argument("--flanking_length", type=int, default=12000, help="The length of the genomic DNA sequence flanking each side of the CRISPR array.  [def. 12000]")
	parser_cas.add_argument("--cas_min", type=int, default=400, help="The minimum length of candidate Cas proteins. Proteins shorter than this value will be excluded from consideration.  [def. 400]")
	parser_cas.add_argument("--cas_max", type=int, default=1000, help="The max length of candidate Cas proteins. Proteins longer than this value will be excluded from consideration.  [def. 1000]")
	parser_cas.add_argument("--motif", type=str, default='RxxxxH', help="Specify the motif pattern to search for in the protein sequence. The motif should be a string where uppercase letters represent fixed amino acids, and lowercase 'x' represents any amino acid or character. For example, 'RxxxxH' will match any sequence where 'R' is followed by four arbitrary amino acids and ending with 'H'. The 'x' can match any character, including non-amino acid characters. [def. RxxxxH]")


	parser_rna = subparsers.add_parser("rna", help="Draw RNA secondary structure.")
	parser_rna.add_argument("fasta_file", help="Input RNA fasta file.")
	parser_rna.add_argument("--row_sum", type=int, default=3, help="Number of results per row.")
	parser_rna.add_argument("--size_base", type=int, default=5, help="Size of the individual plots.")
	parser_rna.add_argument("--dpi", type=int, default=150, help="DPI for the generated PDF.")
	parser_protein = subparsers.add_parser("msa", help="Run protein multiple sequence alignment.")
	parser_protein.add_argument("fasta_file", help="Input protein fasta file or out_name.")
	parser_protein.add_argument('--pt', type=str, help='phylogenetic tree.')
	parser_protein.add_argument('--msa', type=str, help='multiple sequence alignment.')
	parser_protein.add_argument('--tree_width', type=int, default=300,help='width to adjust tree scale.')


	# pdb2dalidb command
	pdb2dalidb_parser = subparsers.add_parser('pdb2dalidb', help='Compare a PDB file with DALI database.')
	pdb2dalidb_parser.add_argument('entry_pdb', type=str, help='PDB file to be compared.')
	pdb2dalidb_parser.add_argument('--dali_database', type=str,default='StructCores',help='Provide a custom database path if needed. By default, uses its built-in core database with experimentally determined CRISPR-Cas structures.')

	# structcompare command
	structcompare_parser = subparsers.add_parser('structcompare', help='Compare predicted PDB structures against a reference fold database to identify structural similarity.')
	structcompare_parser.add_argument('pdb_folder', type=str, help='The name of the folder containing PDB files to be compared.')
	structcompare_parser.add_argument('--dali_database', type=str,default='StructCores',help='Provide a custom database path if needed. By default, uses its built-in core database with experimentally determined CRISPR-Cas structures.')
	structcompare_parser.add_argument('--ymax',type=int,default=20,help='Set the maximum value for the y-axis in the output plot (default: 20).'	)
	structcompare_parser.add_argument('--threads',type=int,default=multiprocessing.cpu_count(),help='Number of threads to use for parallel processing (default: use all available CPU cores).')
	structcompare_parser.add_argument('--width', type=int, default=800,
		help='Width (in pixels) of the output tree image (default: 800).')
	structcompare_parser.add_argument('--inner_width', type=float, default=28,
		help='Width (in inches) of the combined heatmap/dendrogram/tree figure (default: 28).')
	structcompare_parser.add_argument('--inner_height', type=float, default=8,
		help='Height (in inches) of the combined heatmap/dendrogram/tree figure (default: 8).')
	structcompare_parser.add_argument('--linkage_method',type=str,choices=['average', 'ward', 'complete', 'single'],default='average',
		help='Linkage method for hierarchical clustering (default: average)'
	)











	# structmap command
	structmap_parser = subparsers.add_parser('structmap',help='Generate structural comparison matrix and clustering tree from a folder of PDB files.')
	structmap_parser.add_argument('pdb_folder', type=str,help='Folder containing PDB files to be structurally compared.')
	structmap_parser.add_argument('--threads', type=int, default=multiprocessing.cpu_count(),help='Number of threads to use for structural comparisons (default: all CPU cores).')
	structmap_parser.add_argument('--width', type=int, default=800,
		help='Width (in pixels) of the output tree image (default: 800).')
	structmap_parser.add_argument('--inner_width', type=float, default=28,
		help='Width (in inches) of the combined heatmap/dendrogram/tree figure (default: 28).')
	structmap_parser.add_argument('--inner_height', type=float, default=8,
		help='Height (in inches) of the combined heatmap/dendrogram/tree figure (default: 8).')
	structmap_parser.add_argument('--linkage_method',type=str,choices=['average', 'ward', 'complete', 'single'],default='average',
		help='Linkage method for hierarchical clustering (default: average)'
	)

	# makedalidb command
	makedalidb_parser = subparsers.add_parser('makedalidb', help='Create DALI database: Converts a set of PDB files to DALI format numbers for subsequent structural searches.')
	makedalidb_parser.add_argument('directory', type=str, help='Directory containing PDB files.')
	makedalidb_parser.add_argument('--dali_database', type=str, help='Directory for storing the output database files (default: <pdb_folder>_dali_db)')

	# === Add 'scatter' subcommand ===
	scatter_parser = subparsers.add_parser("scatter", help="Generate scatter plots from a CSV file")
	scatter_parser.add_argument("csv_path", help="Path to the input CSV file")
	scatter_parser.add_argument("--x_col", default="pLDDT", help="Column for x-axis (default: pLDDT).")
	scatter_parser.add_argument("--y_col", default="pTM", help="Column for y-axis (default: pTM).")
	scatter_parser.add_argument("--axvline", type=float, default=70, help="Draw a vertical reference line at the specified x-value (default: 70).")
	scatter_parser.add_argument("--axhline", type=float, default=0.7, help="Draw a horizontal reference line at the specified y-value (default: 0.7).")
	scatter_parser.add_argument("--category", required=True, help="Column to categorize and color scatter plot by")
	scatter_parser.add_argument("--output_pdf", default=None, help="Output PDF file name")

	# === Add 'extract_af3_results' subcommand ===
	extract_af3 = subparsers.add_parser("extract_af3_results", help="Extract AF3 prediction results and summary.")
	extract_af3.add_argument("input_dir", type=str, help="Directory containing AF3 prediction subdirectories")
	extract_af3.add_argument("--outdir", type=str, default=None, help="Output directory for extracted results")
	 
	# extract_af3.add_argument("--style", type=str, choices=["square", "balanced"], default="balanced",help="Scatter plot aspect style: 'square' or 'balanced' (default)")


	# === Add 'extract_docking_results' subcommand ===
	extract_hadd = subparsers.add_parser("extract_docking_results", help="Extract HADDOCK score results and summary.")
	extract_hadd.add_argument("input_dir", type=str, help="Directory containing HADDOCK prediction subdirectories")
	extract_hadd.add_argument("--out", type=str, default=None, help="Output name for extracted results")


	# === Add 'run_af3_from_csv' subcommand ===

	run_af3_from_csv = subparsers.add_parser("create_struct_pipeline", help="Create shell scripts for a full protein¡§CRNA structure pipeline.")



	args = parser.parse_args()

	if args.command == "sCas":
		if os.path.isfile(args.assembly_file):
			sCas_scan(args.assembly_file,flanking_length=args.flanking_length,genome_size=args.genome_size,cas_size=args.cas_min,cas_max=args.cas_max,motif=args.motif)
		else:
			print(f"\033[91mThe file {args.assembly_file} does not exist.\033[0m")
			
	elif args.command == "rna":
		if os.path.isfile(args.fasta_file):
			draw_rna_structure(args.fasta_file, row_sum=args.row_sum, size_base=args.size_base, dpi=args.dpi)	
		else:
			print(f"\033[91mThe file {args.fasta_file} does not exist.\033[0m")
	elif args.command == "msa":
		if os.path.isfile(args.fasta_file):
			if  args.pt and args.msa:
				run_protein_msa(args.fasta_file,pt=args.pt,msa=args.msa,tree_width=args.tree_width)
			else:
				run_protein_msa(args.fasta_file,tree_width=args.tree_width)		
		else:
			print(f"\033[91mThe file {args.fasta_file} does not exist.\033[0m")

	elif args.command == 'makedalidb':
		if os.path.isdir(args.directory):	
			print(f'Generating DALI database from {args.directory}...')
			dalidb_dir=args.directory
			dalidb_dir = dalidb_dir.rstrip('/')
			dest_directory=f'{dalidb_dir}_dali'
			if args.dali_database:
				dest_directory=args.dali_database
			if dalidb_dir==dest_directory:
				dest_directory=f'{dalidb_dir}_dali'	
			makedalidb(dalidb_dir,dest_directory)
			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mThe file {args.directory} does not exist.\033[0m")
		# makedalidb(src_directory)  dest_directory=src_directory+'_dali' mol1A.txt.symbol.txt
	elif args.command == 'pdb2dalidb':	
		if os.path.isfile(args.entry_pdb):
			print(f'Comparing {args.entry_pdb} with database {args.dali_database}...')	
			# max_length = 70
			# if len(args.entry_pdb) > max_length or len(args.dali_database) > max_length:
				# print(f"\033[91mERROR: Input parameters must not exceed 70 characters.\033[0m")
				# return 0
			pdb2dalidb(args.entry_pdb,args.dali_database,f"{os.getcwd()}")
			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mThe file {args.entry_pdb} does not exist.\033[0m")	
							
	elif args.command == 'structcompare':	
		args.pdb_folder=os.path.normpath(args.pdb_folder)
		cif_files = [f for f in os.listdir(args.pdb_folder) if f.lower().endswith('.cif')]

		for cif in cif_files:
			cif_path = os.path.join(args.pdb_folder, cif)
			try:
				structure = gemmi.read_structure(cif_path)
				pdb_out = os.path.splitext(cif)[0] + ".pdb"
				structure.write_pdb(os.path.join(args.pdb_folder, pdb_out))
				print(f"[INFO] Converted {cif} to {pdb_out}")
			except Exception as e:
				print(f"[WARNING] Failed to convert {cif}: {e}")

		print(args.pdb_folder)
		if os.path.isdir(args.pdb_folder):
			pdb_files = [f for f in os.listdir(args.pdb_folder) if f.lower().endswith('.pdb')]
			if len(pdb_files) == 0:
				print(f"\033[91mERROR: No PDB files found in the directory: {args.pdb_folder}\033[0m")
				return 0
			print(f'Comparing PDB files in {args.pdb_folder} with database {args.dali_database}...')
			
			if not hasattr(args, 'linkage_method') or args.linkage_method not in allowed_methods:
				print(f"\033[93m[WARNING] Invalid linkage method: {getattr(args, 'linkage_method', None)}. Using default 'average'.\033[0m")
				linkage_method = 'average'
			else:
				linkage_method = args.linkage_method
			structcompare(os.path.normpath(args.pdb_folder), args.dali_database, os.getcwd(), bin_dali='lib_exc',max_threads=args.threads,ymax=args.ymax,z_threshold=8.0,width=args.width,inner_width=args.inner_width,inner_height=args.inner_height,linkage_method=linkage_method)



			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mERROR: The directory {args.pdb_folder} does not exist.\033[0m")
			


	elif args.command == "structmap":

		args.pdb_folder=os.path.normpath(args.pdb_folder)
		if os.path.isdir(args.pdb_folder):
			# === Convert all .cif to .pdb ===
			cif_files = [f for f in os.listdir(args.pdb_folder) if f.lower().endswith('.cif')]

			for cif in cif_files:
				cif_path = os.path.join(args.pdb_folder, cif)
				try:
					structure = gemmi.read_structure(cif_path)
					pdb_out = os.path.splitext(cif)[0] + ".pdb"
					structure.write_pdb(os.path.join(args.pdb_folder, pdb_out))
					print(f"[INFO] Converted {cif} to {pdb_out}")
				except Exception as e:
					print(f"[WARNING] Failed to convert {cif}: {e}")

		
			pdb_files = [f for f in os.listdir(args.pdb_folder) if f.lower().endswith('.pdb')]
			if len(pdb_files) == 0:
				print(f"\033[91mERROR: No PDB files found in the directory: {args.pdb_folder}\033[0m")
				return 0
			# allowed_methods = ['average', 'ward', 'complete', 'single']
			if not hasattr(args, 'linkage_method') or args.linkage_method not in allowed_methods:
				print(f"\033[93m[WARNING] Invalid linkage method: {getattr(args, 'linkage_method', None)}. Using default 'average'.\033[0m")
				linkage_method = 'average'
			else:
				linkage_method = args.linkage_method

			print(f'Comparing PDB files using linkage method: \033[96m{linkage_method}\033[0m')
			compute_dali_matrix(
				os.path.normpath(args.pdb_folder),
				max_threads=args.threads,
				width=args.width,
				inner_width=args.inner_width,
				inner_height=args.inner_height,
				linkage_method=linkage_method
			)
			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mERROR: The directory {args.pdb_folder} does not exist.\033[0m")
			

	elif args.command == "scatter":
		if not os.path.exists(args.csv_path):
			print(f"Error: File '{args.csv_path}' does not exist.")
			exit(1)
		ScatterStruct(args.csv_path, args.x_col, args.y_col, args.category, args.output_pdf,args.axvline,args.axhline)
	elif args.command == "extract_docking_results":
		if not os.path.exists(args.input_dir):
			print(f"Error: File '{args.input_dir}' does not exist.")
			exit(1)	
		extract_haddock(args.input_dir, args.out)


	elif args.command == "extract_af3_results":
		if not os.path.exists(args.input_dir):
			print(f"Error: File '{args.input_dir}' does not exist.")
			exit(1)	
		extract_af3_results(args.input_dir, args.outdir)

	elif args.command == "create_struct_pipeline":
		check_and_create_sh()
		sys.exit(0)


	else:
		parser.print_help()
		
		
		
if __name__ == "__main__":
    main()


