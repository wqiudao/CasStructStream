# CasStructStream.py

"""

usage: casstructstream [-h] {sCas,rna,msa,pdb2dalidb,makedalidb} ...

A tool for designed for Streamlining identification of CRISPR-Cas systems

positional arguments:
  {sCas,rna,msa,pdb2dalidb,makedalidb}
                        Subcommands
    sCas                Streamlined Scanning of CRISPR-Cas Systems.
    rna                 Draw RNA secondary structure.
    msa                 Run protein multiple sequence alignment.
    pdb2dalidb          Compare a PDB file with DALI database.
    makedalidb          Create DALI database: Converts a set of PDB files to DALI format numbers for subsequent structural
                        searches.

options:
  -h, --help            show this help message and exit

"""

import sys,subprocess,os,argparse,re,datetime,shutil,concurrent.futures,random
import matplotlib.pyplot as plt



py_spackages = os.path.dirname(os.path.abspath(__file__))
if py_spackages not in sys.path:
	sys.path.append(py_spackages)
from draw_rna.ipynb_draw import draw_struct
from ete3_lib.ete_view  import *
from ete3_lib  import *
from collections import defaultdict
from draw_rna.mpl2 import *





def remove_extension(pdb_file):
	file_name, _ = os.path.splitext(pdb_file)
	return file_name
def replace_mol1_in_file(mol_txt, new_name1, new_name2=0):
	if not os.path.isfile(mol_txt):
		print(f"\033[91mERROR: The absence of the result file '{mol_txt}' indicates that DaliLite did not run correctly. This may be due to improper configuration of the dependency environment.\033[0m")
		return
	with open(mol_txt, 'r') as f:
		content = f.read()
	if new_name2:	  
		updated_content = content.replace("mol1", remove_extension(new_name1)).replace("mol2", remove_extension(new_name2))
	else:
		updated_content = content.replace("mol1", remove_extension(new_name1))

	with open(mol_txt, 'w') as f:
		f.write(updated_content)
def makedalidb(src_directory,dest_directory,random_number=1000,bin_dali='lib_exc'):
	new_names_dali=set()
	new_names_dali2symbol={}
	log_file=f'{dest_directory}/dali.log'
	hash_file=f'{dest_directory}/dali.hash'
	list_file=f'{dest_directory}/dali.list'
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)	
	# pdb_files_with_random = {}
	old2new_names = {}
	new2ole_names = {}
	for root, dirs, files in os.walk(src_directory):
		for file in files:
			if file.endswith('.pdb'):
				random_number += 1
				new_filename = f"{random_number}.pdb"
				src_file_path = os.path.join(root, file)
				dest_file_path = os.path.join(dest_directory, new_filename)
				
				shutil.copy(src_file_path, dest_file_path)
				new_names_dali.add(dest_file_path)
				new_names_dali2symbol[dest_file_path]=str(random_number)
				old2new_names[file] = new_filename
				new2ole_names[str(random_number)] = file
				# print(f'{file} {new_filename}')
	log_file=open(log_file, 'w')
	hash_file=open(hash_file, 'w')
	list_file=open(list_file, 'w')
	for old_name, new_name in old2new_names.items():
		hash_file.write(f"Old Name: {old_name}, New Name: {new_name}\n")
		list_file.write(f"{new_name.split('.')[0]}A\n")
	hash_file.close()
	list_file.close()
	command = ['chmod', '-R', '+x', os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}']
	result = subprocess.run(command, check=True, capture_output=True, text=True)
	perl_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}/import.pl'
	for filename in new_names_dali:
		# print(f'{new2ole_names[new_names_dali2symbol[filename]]} {filename}')
		# print(new_names_dali2symbol[filename])  running  run_Log
		result = subprocess.Popen(
			['perl', perl_script, '--pdbfile', filename, '--pdbid', new_names_dali2symbol[filename], '--dat', dest_directory, '--clean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
		)
		stdout, stderr = result.communicate()		
		log_file.write(f">>>{new2ole_names[new_names_dali2symbol[filename]]} {filename}<<<\n\n") 
		log_file.write(f"{stdout.decode('utf-8')}")  
		log_file.write(f"{stderr.decode('utf-8')}\n\n") 		
	ref_dali_db=f"{os.getcwd()}/{dest_directory}"
	run_script = 'structalignpro pdb2dalidb'
	print(f"\n{ref_dali_db}\n")
	log_file.close()
	log_file=open(dest_directory+".dali_ref.log", 'w')
	log_file.write(f"{run_script} {ref_dali_db} entry.pdb\n")	
	log_file.close()


def recover_name(pdb2id, query,out_file,pdb,ref_dali_db):
	id2pdb=defaultdict(str) # hash filename  mol1A.txt
	pdb2id_file=open(pdb2id)
	reads=pdb2id_file.readline()
	while reads:
		readss=re.split(r',',reads)
		if len(readss)>1:
			pdb_symbol=re.search(r'(\S+).pdb',readss[0])
			pdb_id=re.search(r'(\d+).pdb',readss[1])
			if pdb_symbol and pdb_id:
				id2pdb[pdb_id.group(1)+'A']=pdb_symbol.group(1).split('___')[0]
				id2pdb[pdb_id.group(1)+'-A']=pdb_symbol.group(1).split('___')[0]
		reads=pdb2id_file.readline()
	pdb2id_file.close()
	query_symbol=open(out_file,'w')
	query_symbol.write(f">>>{pdb} {ref_dali_db}<<<\n\n") 	
	query_file=open(query)
	os.remove('pdbfile1')
	os.remove('ref_dali_db_short')
	reads=query_file.readline()
	while reads:
		for old_name in id2pdb:
			new_name=id2pdb[old_name]
			reads = re.sub(r'\b' + re.escape(old_name) + r'\b', new_name, reads)
		query_symbol.write(reads)
		reads=query_file.readline()
	query_file.close()
	query_symbol.close()

def pdb2dalidb(pdb,ref_dali_db,getcwd_pdb,bin_dali='lib_exc'):
	current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
	print(f"\033[92m{current_time}\033[0m")
	ref_dali_db_log=ref_dali_db
	if ref_dali_db== 'StructCores':
		ref_dali_db = os.path.join(os.path.dirname(os.path.abspath(__file__)), ref_dali_db)

	filename=f'{getcwd_pdb}/{pdb}'
	ref_dali_db = ref_dali_db.rstrip('/')	
	if not os.path.isabs(ref_dali_db):
		ref_dali_db = os.path.join(os.getcwd(), ref_dali_db)
	# max_length = 70
	# if len(filename) > max_length or len(ref_dali_db) > max_length:
		# print(f"\033[91mERROR: Input parameters must not exceed 70 characters.\nThe full path of the directory where the file is located is too lengthy.\033[0m")	
		# print(f"\033[91m{filename}\033[0m")	
		# print(f"\033[91m{ref_dali_db}\033[0m")	
	if not os.path.isdir(ref_dali_db):
		raise FileNotFoundError(f"{ref_dali_db} is not a directory.")
	required_files = ['dali.hash', 'dali.list']
	for file in required_files:
		if not os.path.isfile(os.path.join(ref_dali_db, file)):
			raise FileNotFoundError(f"{file} not found in {ref_dali_db}.")

	dali_ref_list=f'{ref_dali_db}/dali.list'
	dali2symbol=f'{ref_dali_db}/dali.hash'
	# dest_directory=pdb.split(".")[0]+'_dali_rs'
	dest_directory=f'StructAlignPro_{pdb.split(".")[0]}_{current_time}_running'
	# log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{datetime.datetime.now()}.run.log'
	out_file=f'{getcwd_pdb}/StructAlignPro_{pdb.split(".")[0]}_{current_time}_result.txt'
	# log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{datetime.datetime.now()}.run.log'
	# log_file=open(log_file, 'w')
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)		
	shutil.copy(filename, dest_directory)
	print(filename)	
	# print(dali_ref_list)
	# print(dali2symbol)
	# print(f"{os.getcwd()}")
	perl_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}/dali.pl'
	os.chdir(dest_directory)
	
	os.symlink(pdb, 'pdbfile1')	
	os.symlink(ref_dali_db, 'ref_dali_db_short')	
	
	result = subprocess.Popen(
		['perl', perl_script, '--pdbfile1', 'pdbfile1', '--db', dali_ref_list, '--dat1','.', '--dat2', 'ref_dali_db_short', '--title', pdb, '--outfmt','summary,alignments,equivalences,transrot', '--clean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
	)
	stdout, stderr = result.communicate()
	
	log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{current_time}.run.log'
	log_file=open(log_file, 'w')

	log_file.write(f">>>{pdb} {ref_dali_db_log}<<<\n\n") 
	

	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n")
	
	replace_mol1_in_file("mol1A.txt", pdb)
	recover_name(dali2symbol, "mol1A.txt",out_file,pdb,ref_dali_db_log)
	log_file.close()
	print(out_file)


def filter_protein_sequence(sequence):
	valid_aa = "ACDEFGHIKLMNPQRSTVWY"
	sequence = re.sub(r'[\s\*]+', '', sequence.upper())
	sequence = re.sub(r'[^' + valid_aa + ']', '', sequence)
	return sequence
		
		

def find_motif_in_sequence(sequence, motif = "RxxxxH"):
    motif_regex = motif.replace('x', '.')
    matches = re.finditer(motif_regex, sequence)
    matched_motifs = [sequence[match.start():match.end()] for match in matches]
	
    return f'{' '.join(matched_motifs)},{len(matched_motifs)}'


	

def abs_criprs(str1, str2, str3):
	crispr_info = set()
	crispr_info_strand = defaultdict(str) 
	str1s = re.split(r';', str1)
	str2s = re.split(r';', str2)	
	str3s = re.split(r';', str3)	
	for index, (str1, str2, str3) in enumerate(zip(str1s, str2s, str3s)):
		pattern = re.escape(str2) + r'_'  
		result = re.sub(pattern, '', str1)
		#print(f"Index: {index}, str1: {s1}, str2: {s2}, result: {result}")
		
		results=re.split(r'_',result)
		crispr_info_strand[results[0]]=str3
		crispr_info.add(results[0])
	# print(crispr_info)
	# print(str2)
	return crispr_info,str2,crispr_info_strand

def process_file(exec_bin, outfile_tmp, log_file, fasta_file_path, flanking_length, genome_size, cas_size):
    result = subprocess.Popen(
        [exec_bin, '-in', f'{outfile_tmp}.fa', '-out', f'{outfile_tmp}.out'],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    stdout, stderr = result.communicate()
    
    log_file.write(f'#sCas_scan running: {datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}\n')
    log_file.write(f"{fasta_file_path} --flanking_length {flanking_length} --genome_size: {genome_size} --cas_size: {cas_size} \n")
    log_file.write(f"{stdout.decode('utf-8')}\n")
    log_file.write(f"{stderr.decode('utf-8')}\n\n")
    return outfile_tmp

def run_in_threads(exec_bin, outfile_tmps, log_file, fasta_file_path, flanking_length, genome_size, cas_size):

	with concurrent.futures.ThreadPoolExecutor() as executor:

		futures = {
			executor.submit(
				process_file, exec_bin, outfile_tmp, log_file, fasta_file_path, flanking_length, genome_size, cas_size
			): outfile_tmp for outfile_tmp in outfile_tmps
		}
		

		for future in concurrent.futures.as_completed(futures):
			outfile_tmp = futures[future]
			print(f" >>Finished processing {outfile_tmp}")


def reverse_complement(sequence):
    complement = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C', 'U': 'A'}

    return ''.join(complement[base] for base in reversed(sequence))


def sCas_scan(fasta_file_path, flanking_length=12000,genome_size=3000,cas_size=400,pilercr_out='pilercr',min_prodigal=500000,cas_max=1000,motif = "RxxxxH"):
	if cas_max < cas_size:
		cas_max=cas_size+200
	

	prodigal_train_set = set()  
	pilercr_outs = defaultdict(list)  
	current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
	out_index=1  
	pilercr_out=f'{pilercr_out}_{genome_size}'
	# flanking_length=flanking_length*1000
	print(current_time)
	# print(flanking_length)
	print(f"\033[92mcrispr scanning...\033[0m")
	dest_directory=f'CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}_running'
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)		
	# shutil.copy(filename, dest_directory) pilercr   500000000
	os.chdir(dest_directory)

	
	input_fasta=f'../{fasta_file_path}'
	# output_fasta=f'{out_index}_{pilercr_out}.fa'
	sseq_origname = defaultdict(str) 
	sseq_rename=0
	
	fasta_online = defaultdict(str)  #
	fasta_erpin = defaultdict(str)  #
	fasta_erpin_in = defaultdict(str)  #
	with open(input_fasta, "r") as infile:
		sequence = ""
		header = ""
		for line in infile:
			line = line.strip()
			if line.startswith(">"):
				if len(sequence) > genome_size:
					# outfile.write(f"{header}\n{sequence}\n")  
					sseq_rename+=1
					sseq_origname[f'sseq_{sseq_rename}']=header[1:]
					fasta_online[f'sseq_{sseq_rename}']=sequence
					prodigal_train_set.add(f'sseq_{sseq_rename}')
				
				header = line
				sequence = ""
			else:
				sequence += line
		if len(sequence) > genome_size:
			# outfile.write(f"{header}\n{sequence}\n")
			sseq_rename+=1
			sseq_origname[f'sseq_{sseq_rename}']=header[1:]
			fasta_online[f'sseq_{sseq_rename}']=sequence
			prodigal_train_set.add(f'sseq_{sseq_rename}')
 
 # , open(output_fasta, "w") as outfile
	sum_bases=0
	out_index_tmp=0
	outfile_tmps = set()  #
	outfile_tmp=f'{out_index}_{pilercr_out}_{out_index_tmp}'
	outfile_tmps.add(outfile_tmp)
	for scaffold_id in fasta_online:
		sum_bases+=len(fasta_online[scaffold_id])
		if sum_bases>550000000:
		# if sum_bases>5500000:
			sum_bases=0
			out_index_tmp+=1
			outfile_tmp=f'{out_index}_{pilercr_out}_{out_index_tmp}'
			outfile_tmps.add(outfile_tmp)
		with open(f'{outfile_tmp}.fa', "a") as outfile:
			outfile.write(f">{scaffold_id}\n{fasta_online[scaffold_id]}\n")
			
			
	log_file=f'0_{fasta_file_path.split(".")[0]}_{current_time}.running.log'
	log_file=open(log_file, 'w')
	exec_bin = 'pilercr'

	run_in_threads(exec_bin, outfile_tmps, log_file, fasta_file_path, flanking_length, genome_size, cas_size)

	print(f"\033[92mcrispr done...\033[0m")
	outfile_tmp_union=open(f'{out_index}_{pilercr_out}_union.out','w')
	for outfile_tmp in outfile_tmps:
		pilercr_is=False
		with open(f'{outfile_tmp}.out', "r") as infile:
			for line in infile:
				outfile_tmp_union.write(f'{line}\n')
				if re.match(r'SUMMARY\s+BY\s+SIMILARITY',line.strip()):
					pilercr_is=True
					# print(line)
				if re.match(r'SUMMARY\s+BY\s+POSITION',line.strip()):
					break
				if pilercr_is:
					lines=re.split(r"\s+",line.strip())
					if lines[0].isdigit():
						# print(lines[1])
						if lines[1] in prodigal_train_set:
							prodigal_train_set.remove(lines[1])
							# print(lines[1])
						
						pilercr_in=f'{lines[1]}_{lines[2]}_{lines[3]}'
						fasta_erpin_in[pilercr_in]=fasta_online[lines[1]][int(lines[2])-1:int(lines[3])+int(lines[2])]
						lines[3]=int(lines[2])+int(lines[3])+flanking_length
						lines[2]=max(int(lines[2])-flanking_length-1,0)
						lines[8]=re.sub(r'[^ATCG]', '', lines[8], flags=re.IGNORECASE)
						if lines[7]=='-':
							# print(f'old {lines}')
							lines[8]=reverse_complement(lines[8])
							# print(f'new {lines}')
						pilercr_outs[pilercr_in]=lines

	# print(pilercr_outs)	
	# print(prodigal_train_set)	
	outfile_tmp_union.close()
	
	with open(f'{out_index+2}_{pilercr_out}_prodigal.fa', "w") as outfile:
		for pilercr_in in pilercr_outs:
			sequence_in=fasta_online[pilercr_outs[pilercr_in][1]][pilercr_outs[pilercr_in][2]:pilercr_outs[pilercr_in][3]]
			out_index+=len(sequence_in)
			outfile.write(f">{pilercr_in}\n{sequence_in}\n")
			fasta_erpin[pilercr_in]=fasta_online[pilercr_outs[pilercr_in][1]].replace(fasta_erpin_in[pilercr_in], '-' * len(fasta_erpin_in[pilercr_in]))
		# print(f'out_index {out_index}')
		if out_index<min_prodigal:
			# print(list(prodigal_train_set)[0:max((min_prodigal-out_index)//3000,1)])
			for scaffold_in in list(prodigal_train_set)[0:max((min_prodigal-out_index)//3000,1)]:
				outfile.write(f">{scaffold_in}\n{fasta_online[scaffold_in]}\n")	
	fasta_online.clear()	

	if out_index<20000:
		print(f"\033[91mError: {out_index}bp Too short for protein prediction. The minimum required genome length is 20000 bp.\033[0m")
		return 0
	
	out_index=1  	
	
	print(f"\033[92mprodigal running...\033[0m")
	# prodigal -c  -a  temp.pep   -i  temp  -p single  -f gff  -o  temp.gff pep
	exec_bin = 'prodigal'
	result = subprocess.Popen(
		[exec_bin, '-c', '-a', f'{out_index+3}_{pilercr_out}.pep', '-i',f'{out_index+2}_{pilercr_out}_prodigal.fa', '-p', 'single', '-f', 'gff', '-o', f'{pilercr_out}.gff'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
	)
	# log_file=f'0_{fasta_file_path.split(".")[0]}_{current_time}.running.log'
	# log_file=open(log_file, 'a')
	stdout, stderr = result.communicate()
	log_file.write(f">>>prodigal running...<<<\n\n") 
	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n")
	print(f"\033[92mprodigal done...\033[0m")
	
	
	print(f"\033[92mhmmscan running...\033[0m")
	# prodigal -c  -a  temp.pep   -i  temp  -p single  -f gff  -o  temp.gff pep
	exec_bin = 'hmmscan'
	result = subprocess.Popen(
		[exec_bin, '-E', '1e-5', '--tblout', f'{out_index+3}_{pilercr_out}.hmmscan',os.path.dirname(os.path.abspath(__file__))+'/hmm_cas/cas_db_all.hmm', f'{out_index+3}_{pilercr_out}.pep'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
	)
	# log_file=f'0_{fasta_file_path.split(".")[0]}_{current_time}.running.log'
	# log_file=open(log_file, 'a')
	stdout, stderr = result.communicate()
	log_file.write(f">>>prodigal running...<<<\n\n") 
	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n")
	print(f"\033[92mhmmscan done...\033[0m")
	# hmmscan  --tblout t13.txt  -E 1e-5   hmm_cas/cas_db_all.hmm t13.fasta
	print(f"\033[92mparsing and visualization...\033[0m")
	# fasta_online = defaultdict(str)  #
	protein_strands = defaultdict(str)  #
	hmm_rs_hit=set()
	with open(f'{out_index+3}_{pilercr_out}.pep', "r") as infile:
		sequence = ""
		header = ""
		for line in infile:
			line = line.strip()
			if line.startswith(">"):
				if len(sequence) > cas_size and len(sequence) <= cas_max:
					headers=re.split(r'\s+',header[1:])
					headerss=re.split(r'_',headers[0])
					# fasta_online[re.sub(r'_\d+$', '', headers[0])]=sequence 2 4
					# print(headers)        max(int(headerss[-3])-flanking_length-1,0)
					protein_strand='+'
					if headers[6]=='-1':
						protein_strand='-'
					
					pilercr_in=re.sub(r'_\d+$', '', headers[0])
					if pilercr_in in pilercr_outs:
						# print(f'{len(headerss)} {max(int(headerss[-3])-flanking_length-1,0)} {headerss[-3]} {headers[0]} {protein_strand} {re.sub(r'_\d+$', '', headers[0])}')
						# print(headers)   filter_protein_sequence(scaffold_fasta)
						prefix_padding=max(int(headerss[-3])-flanking_length-1,0)
						fasta_online[headers[0]]=filter_protein_sequence(sequence)
						protein_strands[headers[0]]=f'{protein_strand},{int(headers[2])+prefix_padding},{int(headers[4])+prefix_padding}'
						
						
				header = line
				sequence = ""
			else:
				sequence += line
		if len(sequence) > cas_size and len(sequence) <= cas_max:
			# headers=re.split(r'\s+',header[1:])
			# # fasta_online[re.sub(r'_\d+$', '', headers[0])]=sequence			
			# fasta_online[headers[0]]=sequence			
			headers=re.split(r'\s+',header[1:])
			headerss=re.split(r'_',headers[0])
			# fasta_online[re.sub(r'_\d+$', '', headers[0])]=sequence 2 4
			# print(headers)        max(int(headerss[-3])-flanking_length-1,0)
			protein_strand='+'
			if headers[6]=='-1':
				protein_strand='-'
			pilercr_in=re.sub(r'_\d+$', '', headers[0])
			if pilercr_in in pilercr_outs:
				# print(f'{len(headerss)} {max(int(headerss[-3])-flanking_length-1,0)} {headerss[-3]} {headers[0]} {protein_strand} {re.sub(r'_\d+$', '', headers[0])}')
				# print(headers)
				prefix_padding=max(int(headerss[-3])-flanking_length-1,0)
				fasta_online[headers[0]]=filter_protein_sequence(sequence)
				protein_strands[headers[0]]=f'{protein_strand},{int(headers[2])+prefix_padding},{int(headers[4])+prefix_padding}'
				
	
	sCas_scans = defaultdict(str) #last protein index
	sCas_hmscan = defaultdict(str) #last protein index

	with open(f'{out_index+3}_{pilercr_out}.hmmscan', "r") as infile:
		for line in infile:
			lines=re.split(r'\s+',line.strip())
			if len(lines)>3:
				sCas_hmscan[lines[2]]+=f'{lines[0]};'

	#print(sCas_hmscan)
	#dr_of=open(f'DR_{fasta_file_path.split(".")[0]}_{current_time}.fa', 'w')
	outfile_tmps = set()  #
	dr_seqs = set()  #
	out_index_tmp=0
	
	for scaffold_id in fasta_online:
		# print(scaffold_id)
		# print(sCas_hmscan[scaffold_id])
		scaffold_id2=re.sub(r'_\d+$', '', scaffold_id)  #protein id only
		if scaffold_id2 not in pilercr_outs:
			continue
		# print(f'{scaffold_id} {scaffold_id2} {pilercr_outs[scaffold_id2]}') sseq_origname[scaffold_id2] sseq_origname[scaffold_id2]
		pilercr_outs[scaffold_id2][0]=scaffold_id
		
		sCas_scans_tmp=pilercr_outs[scaffold_id2].copy()
		sCas_scans_tmp.append(scaffold_id)		
		sCas_scans_tmp.append(sseq_origname[re.sub(r'_\d+_\d+$', '', scaffold_id2)])		
		# print(pilercr_outs[scaffold_id2])
		# print(sCas_scans_tmp) 
		# print(scaffold_id) 
		# print(scaffold_id2) 
		# print(re.sub(r'_\d+_\d+_\d+$', '', scaffold_id)) 
		#dr_of.write(f'>{sCas_scans_tmp[10]}\n{sCas_scans_tmp[8]}\n')
		if sCas_scans_tmp[8] not in dr_seqs:
			dr_seqs.add(sCas_scans_tmp[8])
			outfile_tmps.add(f'DR_{fasta_file_path.split(".")[0]}_{current_time}_{out_index_tmp//60}')
			with open(f'DR_{fasta_file_path.split(".")[0]}_{current_time}_{out_index_tmp//60}.fa', "a") as dr_of:
				dr_of.write(f'>{sCas_scans_tmp[10]}\n{sCas_scans_tmp[8]}\n')
			out_index_tmp+=1
		

		if fasta_online[scaffold_id] in sCas_scans:
			for sCas_inner in range(0,len(sCas_scans[fasta_online[scaffold_id]])):
				sCas_scans[fasta_online[scaffold_id]][sCas_inner]=f'{str(sCas_scans[fasta_online[scaffold_id]][sCas_inner])};{str(sCas_scans_tmp[sCas_inner])}'	
		else:
			sCas_scans[fasta_online[scaffold_id]]=sCas_scans_tmp
		
		hmm_rs=None
		if scaffold_id in sCas_hmscan:
			hmm_rs = sCas_hmscan[scaffold_id]
			hmm_rs_hit.add(fasta_online[scaffold_id])
		# hmm_rs = sCas_hmscan[scaffold_id] if scaffold_id in sCas_hmscan else None
		protein_strands[fasta_online[scaffold_id]]=f'{protein_strands[scaffold_id]},{hmm_rs}'
		# protein_strands
	#dr_of.close()	
	fasta_online.clear()
	for outfile_tmp in outfile_tmps:
		draw_rna_structure(f'{outfile_tmp}.fa',row_sum=4,is_show=False)
		shutil.copy(f'{outfile_tmp}_RNA_Struct.pdf', f'../RNA_Struct_DR_{outfile_tmp}.pdf')
	
	
	# draw_rna_structure(f'DR_{fasta_file_path.split(".")[0]}_{current_time}.fa',row_sum=4,is_show=False)
	os.chdir('..')
	# shutil.copy(f'{dest_directory}/DR_{fasta_file_path.split(".")[0]}_{current_time}_RNA_Struct.pdf', f'RNA_Struct_DR_{fasta_file_path.split(".")[0]}_{current_time}.pdf')
	
	crispr_locs = defaultdict(set)  #
	crispr_locs_strands = defaultdict(str)  #
	protein_locs = defaultdict(set)  #
	protein_locs_strands = defaultdict(str)  #
	# print(pilercr_outs) sseq_origname[f'sseq_{sseq_rename}']
	sCas_index=0
	with open(f'CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}.csv', "w") as outfile, open(f'{dest_directory}/CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}.fasta', "w") as outfile2, open(f'{dest_directory}/CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}_hmm_cas.fasta', "w") as outfile3, open(f'{dest_directory}/CRISPRCasStream_{fasta_file_path.split(".")[0]}_{current_time}_crispr_mask.fasta', "w") as outfile4:
		outfile.write(f'sCas,Sequence,Len_Sequence,strand_Cas,Start_Cas,End_Cas,hmm_cas,Scaffold_cripr_info,Scaffold,Start_crispr_flanking,End_crispr_flanking,Copies,Len_Repeat,Len_Spacer,Strand_Repeat,Seq_Repeat,pep_id,orig_Scaffold_name,MOTIF: {motif},motif_count\n')
		for scaffold_fasta in sCas_scans:
			sCas_index+=1
			# pilercr_outss=pilercr_outs[scaffold_id][1:]	
			# print(",".join(pilercr_outss))
			# string_data = ",".join(map(str, pilercr_outss))
			# outfile.write(f'{scaffold_id},{fasta_online[scaffold_id]},{",".join(map(str, pilercr_outss))}\n')
			outfile2.write(f'>sCas_{sCas_index} {sCas_scans[scaffold_fasta][-3]}\n{scaffold_fasta}\n')
			if scaffold_fasta in hmm_rs_hit:
				outfile3.write(f">sCas_{sCas_index} {sCas_scans[scaffold_fasta][-1]} {protein_strands[scaffold_fasta]} {re.sub(r'T', 'U', sCas_scans[scaffold_fasta][-3], flags=re.IGNORECASE)}\n{scaffold_fasta}\n")
			outfile.write(f'sCas_{sCas_index},{scaffold_fasta},{len(scaffold_fasta)},{protein_strands[scaffold_fasta]},{",".join(map(str, sCas_scans[scaffold_fasta]))},{find_motif_in_sequence(scaffold_fasta, motif)}\n')
			# print(sCas_scans[scaffold_fasta])
			
			crispr_infos,scaffold_id,crispr_info_strand=abs_criprs(sCas_scans[scaffold_fasta][0], sCas_scans[scaffold_fasta][1], sCas_scans[scaffold_fasta][7])
			# print(crispr_info_strand)
			# print(scaffold_id)
			# print(protein_strands[scaffold_fasta].split(",")[1]) 
			crispr_locs[scaffold_id]=crispr_locs[scaffold_id].union(crispr_infos)
			# crispr_locs_strands[scaffold_id]=crispr_info_strand
			if not crispr_locs_strands[scaffold_id]:
				crispr_locs_strands[scaffold_id]={}
			crispr_locs_strands[scaffold_id].update(crispr_info_strand)


			protein_stinfo=protein_strands[scaffold_fasta].split(",")
			protein_locs[scaffold_id].add(protein_stinfo[1])
			protein_locs_strands[protein_stinfo[1]]=protein_stinfo[0]

			outfile4.write(f">sCas_{sCas_index} {sCas_scans[scaffold_fasta][-1]} {protein_strands[scaffold_fasta]} {sCas_scans[scaffold_fasta][-3]}\n{fasta_erpin[re.sub(r'_\d+$', '', sCas_scans[scaffold_fasta][0].split(';')[0])]}\n")
		
			

		

	log_file.write(f'\n#sCas_scan done: {datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}\n\n')
	log_file.close()

	num_rows = len(crispr_locs)
	if num_rows>0:
		num_rows_per_page=min(60,num_rows)
		
		num_pages = (num_rows + num_rows_per_page - 1) // num_rows_per_page  

		for page in range(num_pages):
			# print(page)
			figsize_height=num_rows_per_page
			if page==(num_pages-1):
				figsize_height=num_rows-num_rows_per_page*page
				# print(num_rows-num_rows_per_page*page)
			
			
			fig, axs = plt.subplots(min(num_rows_per_page, num_rows - page * num_rows_per_page), 1, figsize=(6, 1.8 * figsize_height))
			
			for i in range(min(num_rows_per_page, num_rows - page * num_rows_per_page)):
				scaffold_id = list(crispr_locs.keys())[page * num_rows_per_page + i]  # 
				rectangle_positions = sorted([int(loc) for loc in list(protein_locs[scaffold_id])])
				rectangle_positions_labs = [f'{p_loc}_{protein_locs_strands[str(p_loc)]}' for p_loc in rectangle_positions]
				
				crispr_positions = sorted([int(loc) for loc in list(crispr_locs[scaffold_id])])
				crispr_labs = [f'{p_loc}_{crispr_locs_strands[scaffold_id][str(p_loc)]}' for p_loc in crispr_positions]
				ax = axs[i] if num_rows > 1 else axs
				ax.set_facecolor('#f0f0f0')
				ax.set_title(f'{i + 1 + page * num_rows_per_page}: {scaffold_id} {sseq_origname[scaffold_id]}', fontsize=10, loc='left', y=0.75)
				ax.axis('equal')
				draw_crispr(ax, crispr_positions, crispr_labs, rectangle_positions, rectangle_positions_labs)
				ax.axis('off')
				ax.grid(False)

			plt.tight_layout()
			pdf_opt = f'sCas_scan_{datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}_page_{page + 1}.pdf'  # 
			plt.savefig(pdf_opt, format='pdf')
			plt.close(fig)  # 
		
		
	# plt.show()
	print(f"\033[92mDone...\033[0m {num_rows}")


def draw_rna_structure(fasta_file_path, row_sum=3, size_base=5, dpi=150,bin_exc='lib_exc',is_show=True):
	def extract_lines(filename):
		with open(filename, 'r') as file:
			lines = file.readlines()
		structure = re.split(r'\s+', lines[2].strip())[0]
		free_energy = lines[3].strip()   
		return structure, free_energy

	def run_rnafold(sequence):
		input_file = 'temp_sequence.fasta'
		with open(input_file, 'w') as f:
			f.write(f'>sequence\n{sequence}\n')

		output_file = f'{input_file}.RNAfold.tmp'
		
		exc_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_exc}/RNAfold'
		
		command = [exc_script, '-p0', f'-o{output_file}', input_file]

		try:
			subprocess.run(command, check=True)
			structure, free_energy = extract_lines(output_file)
			os.remove(output_file)
			os.remove(input_file)   
			os.remove("sequence_ss.ps")   
			return structure, free_energy
		except subprocess.CalledProcessError as e:
			print(f'Error occurred while running RNAfold: {e}')
			return 0

	 
	def read_fasta(file_path):
		labs = []
		seqs = []
		with open(file_path, 'r') as f:
			seq = ""
			for line in f:
				line = line.strip()
				if line.startswith(">"):
					if seq:   
						seqs.append(seq)
						seq = ""
					labs.append(line[1:])  
				else:
					seq += line   
			if seq:  
				seqs.append(seq)
		return labs, seqs

	labs, seqs = read_fasta(fasta_file_path)
	opt_name = f"{os.path.splitext(fasta_file_path)[0]}_RNA_Struct"
	units_number = len(labs)

	col_sum = len(labs) // row_sum   
	if len(labs) % row_sum:
		col_sum += 1
	
	max_sizes=[]
	
		
	for seq in seqs:
		fig, temp_ax = plt.subplots()
		structure, free_energy = run_rnafold(seq)
		max_size=draw_struct(seq, structure, ax=temp_ax)
		plt.close(fig)
		max_sizes.append(max_size)	
		
	max_sizes_base=max(max_sizes)
 
	i_size=0
	for lab_id in range(0, len(labs), units_number):
		 
		if row_sum == 1:
			fig, axes = plt.subplots(col_sum, 1, figsize=(size_base * 2, size_base * 2 * col_sum))
			axes = [axes] if col_sum == 1 else axes
		else:
			fig, axes = plt.subplots(col_sum, row_sum, figsize=(size_base * 2 * row_sum, size_base * 2 * col_sum))
		
		for i, ax in enumerate(axes.flat if row_sum > 1 else axes):
			
			lab_i = i + lab_id
			if lab_i + 1 > units_number:
				break
			# print(str(lab_i + 1) + "\t" + seqs[lab_i] + "\t" + labs[lab_i])
			is_show and print(f'{lab_i + 1} {seqs[lab_i]} {labs[lab_i]}')
			
			seq = seqs[lab_i]
			structure, free_energy = run_rnafold(seq)
			ax.set_title(labs[lab_i] + '\n' + seq + '\n' + free_energy,fontsize=size_base * row_sum)

			
			scale_factor = max_sizes[i_size]/max_sizes_base  
			
			row_index = i // row_sum
			col_index = i % row_sum
			
			left = 0.0 + col_index * (0.8 / row_sum)  
			bottom = 0.0 + (col_sum - 1 - row_index) * (1 / col_sum)
			
			ax.set_position([left, bottom, 0.9 * scale_factor / row_sum, 0.9 * scale_factor / col_sum])
		
			
			draw_struct(seq, structure, ax=ax)
			i_size+=1
			# max_sizes.append(max_size) max_sizes_base

			
		if i==units_number:
			i-=1			
 
		for j in range(i+1, len(axes.flat if row_sum > 1 else axes)):
			fig.delaxes(axes.flat[j] if row_sum > 1 else axes[j])
			# print(f'delaxes: {j}')
		plt.savefig(f'{opt_name}.pdf', dpi=dpi, bbox_inches='tight')
def run_protein_msa(ipt_query,pt='',msa='',bin_exc='lib_exc',tree_width=300):
	opt = ipt_query
	tree_ipt=pt
	msa_ipt=msa

	if pt:

		print('Skip multiple sequence alignment (MSA) and phylogenetic tree drawing...')
		
	else:
		opt = os.path.splitext(ipt_query)[0]	
		# output_fasta='{}.checked.fasta'.format(opt)
		output_fasta=f'{opt}.checked.fasta'
		output_fasta2=f'{opt}.msa'
		tree_ipt=f'{opt}.muscle.tree'
		msa_ipt=f'{opt}.muscle.fas'
		log_file=open(f'{opt}.ms.log', 'w')		
		print(f"\033[92mCheck for duplicates in FASTA headers and replace invalid characters....\033[0m")
		
		fasta_headers = defaultdict(int)  #

		with open(ipt_query, "r") as infile, open(output_fasta, "w") as outfile, open(output_fasta2, "w") as outfile2:
			sequence = ""
			header = ""
			outfile2.write(f"(")
			for line in infile:
				line = line.strip()
				if line.startswith(">"):
					if sequence:
						outfile.write(f">{header}\n{filter_protein_sequence(sequence)}\n")
						outfile2.write(f"{header}:0,")
					

					header_orig = re.sub(r'\W+', '_', line[1:])
					header = header_orig
					
					if header_orig in fasta_headers:
						header=f'{header_orig}_{fasta_headers[header_orig]}'
					fasta_headers[header_orig]+=1
						
						
					 
					sequence = ""	
				else:
					sequence += line
			if sequence:
				outfile.write(f">{header}\n{filter_protein_sequence(sequence)}\n")
				outfile2.write(f"{header}:0);")

		print('...Begin to run muscle...')
		exc_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_exc}/muscle'
		result = subprocess.Popen([exc_script, '-in', output_fasta, '-out', msa_ipt],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  
		stdout, stderr = result.communicate()
		
		log_file.write(f'#protein_msa running: {datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}\n')
		log_file.write(f">>>muscle running...<<<\n\n") 
		log_file.write(f"{stdout.decode('utf-8')}")  
		log_file.write(f"{stderr.decode('utf-8')}\n\n")

 
		print('...Begin to run FastTree...')
		exc_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_exc}/FastTree'
		with open(tree_ipt, 'w') as outfile:
			result=subprocess.Popen([exc_script, msa_ipt],stdout=outfile,stderr=subprocess.PIPE)
			stdout, stderr = result.communicate()
			log_file.write(f">>>FastTree running...<<<\n\n")   
			log_file.write(f"{stderr.decode('utf-8')}\n\n")

		# exc_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_exc}/ete3'
		# subprocess.call([exc_script, 'view', '-t', '{}.muscle.tree'.format(opt), '--alg', '{}.muscle.fas'.format(opt), '--alg_type', 'compactseq', '-i', 'msa_ete3_{}.pdf'.format(opt)])
		
		log_file.close()


	print('...Generating PDF with ete3...')

	args = argparse.Namespace(
		src_trees=[output_fasta2],
		src_tree_list=None,
		src_tree_attr='name',
		src_attr_parser=None,
		src_newick_format=0,
		output=None,
		verbosity=2,
		face=None,
		mode='r',
		image=f'{opt}_MSA.pdf',
		text_mode=False,
		show_attributes=None,
		width=0,
		height=0,
		resolution=300,
		size_units='px',
		branch_separation=3,
		show_support=False,
		show_branch_length=False,
		force_topology=False,
		hide_leaf_names=False,
		show_internal_names=False,
		tree_width=tree_width,
		color_by_rank=None,
		raxml=False,
		alg=msa_ipt,
		alg_type='compactseq',
		alg_format='fasta',
		as_ncbi=False,
		heatmap=None,
		profile=None,
		bubbles=None,
		func=ete_view.run   
	)
	 
	args.func(args)
	
	os.remove(output_fasta2)	

	args = argparse.Namespace(
		src_trees=[tree_ipt],
		src_tree_list=None,
		src_tree_attr='name',
		src_attr_parser=None,
		src_newick_format=0,
		output=None,
		verbosity=2,
		face=None,
		mode='r',
		image=f'{opt}_MSA_TREE.pdf',
		text_mode=False,
		show_attributes=None,
		width=0,
		height=0,
		resolution=300,
		size_units='px',
		branch_separation=3,
		show_support=False,
		show_branch_length=False,
		force_topology=False,
		hide_leaf_names=False,
		show_internal_names=False,
		tree_width=tree_width,
		color_by_rank=None,
		raxml=False,
		alg=msa_ipt,
		alg_type='compactseq',
		alg_format='fasta',
		as_ncbi=False,
		heatmap=None,
		profile=None,
		bubbles=None,
		func=ete_view.run   
	)
	 
	args.func(args)
	print(f"\033[92mDone....\033[0m")
  
def main():
	parser = argparse.ArgumentParser(prog='casstructstream',description="A tool for designed for  Streamlining identification  of CRISPR-Cas systems")
	
	
	subparsers = parser.add_subparsers(dest="command", help="Subcommands")
	parser_cas = subparsers.add_parser("sCas", help="Streamlined Scanning of CRISPR-Cas Systems.")
	parser_cas.add_argument("assembly_file", help=" Input assembly file in FASTA format.")
	parser_cas.add_argument("--genome_size", type=int, default=3000, help="The minimum scaffold length for genome assembly. Scaffolds shorter than this value will be excluded from the assembly. [def. 3000]")
	parser_cas.add_argument("--flanking_length", type=int, default=12000, help="The length of the genomic DNA sequence flanking each side of the CRISPR array.  [def. 12000]")
	parser_cas.add_argument("--cas_min", type=int, default=400, help="The minimum length of candidate Cas proteins. Proteins shorter than this value will be excluded from consideration.  [def. 400]")
	parser_cas.add_argument("--cas_max", type=int, default=1000, help="The max length of candidate Cas proteins. Proteins longer than this value will be excluded from consideration.  [def. 1000]")
	parser_cas.add_argument("--motif", type=str, default='RxxxxH', help="Specify the motif pattern to search for in the protein sequence. The motif should be a string where uppercase letters represent fixed amino acids, and lowercase 'x' represents any amino acid or character. For example, 'RxxxxH' will match any sequence where 'R' is followed by four arbitrary amino acids and ending with 'H'. The 'x' can match any character, including non-amino acid characters. [def. RxxxxH]")
	
	
	parser_rna = subparsers.add_parser("rna", help="Draw RNA secondary structure.")
	parser_rna.add_argument("fasta_file", help="Input RNA fasta file.")
	parser_rna.add_argument("--row_sum", type=int, default=3, help="Number of results per row.")
	parser_rna.add_argument("--size_base", type=int, default=5, help="Size of the individual plots.")
	parser_rna.add_argument("--dpi", type=int, default=150, help="DPI for the generated PDF.")
	parser_protein = subparsers.add_parser("msa", help="Run protein multiple sequence alignment.")
	parser_protein.add_argument("fasta_file", help="Input protein fasta file or out_name.")
	parser_protein.add_argument('--pt', type=str, help='phylogenetic tree.')
	parser_protein.add_argument('--msa', type=str, help='multiple sequence alignment.')
	parser_protein.add_argument('--tree_width', type=int, default=300,help='width to adjust tree scale.')
	
	
	# pdb2dalidb command
	pdb2dalidb_parser = subparsers.add_parser('pdb2dalidb', help='Compare a PDB file with DALI database.')
	pdb2dalidb_parser.add_argument('entry_pdb', type=str, help='PDB file to be compared.')
	pdb2dalidb_parser.add_argument('--dali_database', type=str,default='StructCores',help='Provide a custom database path if needed. By default, uses its built-in core database with experimentally determined CRISPR-Cas structures.')

	# makedalidb command
	makedalidb_parser = subparsers.add_parser('makedalidb', help='Create DALI database: Converts a set of PDB files to DALI format numbers for subsequent structural searches.')
	makedalidb_parser.add_argument('directory', type=str, help='Directory containing PDB files.')
	makedalidb_parser.add_argument('--dali_database', type=str, help='Directory for storing the output database files (default: <pdb_folder>_dali_db)')

	
	args = parser.parse_args()
	
	if args.command == "sCas":
		if os.path.isfile(args.assembly_file):
			sCas_scan(args.assembly_file,flanking_length=args.flanking_length,genome_size=args.genome_size,cas_size=args.cas_min,cas_max=args.cas_max,motif=args.motif)
		else:
			print(f"\033[91mThe file {args.assembly_file} does not exist.\033[0m")
			
	elif args.command == "rna":
		if os.path.isfile(args.fasta_file):
			draw_rna_structure(args.fasta_file, row_sum=args.row_sum, size_base=args.size_base, dpi=args.dpi)	
		else:
			print(f"\033[91mThe file {args.fasta_file} does not exist.\033[0m")
	elif args.command == "msa":
		if os.path.isfile(args.fasta_file):
			if  args.pt and args.msa:
				run_protein_msa(args.fasta_file,pt=args.pt,msa=args.msa,tree_width=args.tree_width)
			else:
				run_protein_msa(args.fasta_file,tree_width=args.tree_width)		
		else:
			print(f"\033[91mThe file {args.fasta_file} does not exist.\033[0m")
	
	elif args.command == 'makedalidb':
		if os.path.isdir(args.directory):	
			print(f'Generating DALI database from {args.directory}...')
			dalidb_dir=args.directory
			dalidb_dir = dalidb_dir.rstrip('/')
			dest_directory=f'{dalidb_dir}_dali'
			if args.dali_database:
				dest_directory=args.dali_database
			if dalidb_dir==dest_directory:
				dest_directory=f'{dalidb_dir}_dali'	
			makedalidb(dalidb_dir,dest_directory)
			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mThe file {args.directory} does not exist.\033[0m")
			
		# makedalidb(src_directory)  dest_directory=src_directory+'_dali' mol1A.txt.symbol.txt
	elif args.command == 'pdb2dalidb':	
		if os.path.isfile(args.entry_pdb):
			print(f'Comparing {args.entry_pdb} with database {args.dali_database}...')	
			# max_length = 70
			# if len(args.entry_pdb) > max_length or len(args.dali_database) > max_length:
				# print(f"\033[91mERROR: Input parameters must not exceed 70 characters.\033[0m")
				# return 0
			pdb2dalidb(args.entry_pdb,args.dali_database,f"{os.getcwd()}")
			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mThe file {args.entry_pdb} does not exist.\033[0m")	
	else:
		parser.print_help()
		
 		
		
if __name__ == "__main__":
    main()

