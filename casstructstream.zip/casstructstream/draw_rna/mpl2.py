import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse,FancyBboxPatch
 
colors = {
    "r": [255, 102, 102],
    "g": [113, 188, 120],
    "b": [51, 153, 255],
    "p": [255, 210, 200],
    "k": [1, 0, 0],
    "y": [255, 211, 0],
    "c": [0, 255, 255],
    "m": [255, 0, 255],
    "w": [255, 255, 255],
    "e": [100, 100, 100],
    "f": [200, 200, 200],
    "o": [231, 115, 0],
    "i": [51, 204, 204],
    "h": [51, 153, 255],
    "u": [138, 43, 226]
}

def draw_dna_double_helix_2d_with_style(ax, length=10, color1=[255, 102, 102], color2=[51, 153, 255], 
                                          x_offset=0, y_offset=0, linewidth=3):
    num_turns = length / 1.2  
    inner_radius = 0.2  
    offset_angle = np.pi / 3  
    theta = np.linspace(0, num_turns * 2 * np.pi, 100)
    x1 = np.linspace(0, length, 100) + x_offset
    y1 = inner_radius * np.sin(theta) + y_offset
    x2 = np.linspace(0, length, 100) + x_offset
    y2 = inner_radius * np.sin(theta + np.pi + offset_angle) + y_offset
    
    
    line1 = ax.plot(x1, y1, color=np.array(color1) / 255, linewidth=linewidth, alpha=0.8, label='Strand 1')
    line1[0].set_zorder(5)  

    
    line2 = ax.plot(x2, y2, color=np.array(color2) / 255, linewidth=linewidth, alpha=0.8, label='Strand 2')
    line2[0].set_zorder(5)  
    
    
    fill1 = ax.fill_between(x1, y1 - 0.05, y1 + 0.05, color=np.array(color1) / 255, alpha=0.1)
    

    fill2 = ax.fill_between(x2, y2 - 0.05, y2 + 0.05, color=np.array(color2) / 255, alpha=0.1)
   
def draw_spacer(ax, center_x, center_y, width=0.3, rect_width=0.2, aspect_ratio=3, 
                ellipse_color=[128, 0, 128], rectangle_color=[128, 0, 128]):
    height = width * aspect_ratio
    width=width/1.5
    rect_width=rect_width/2
    shadow_ellipse = Ellipse((center_x + 0.02, center_y - 0.02), width, height, edgecolor='none', 
                              facecolor='gray', alpha=0.5)
    ax.add_patch(shadow_ellipse)
    
    ellipse = Ellipse((center_x, center_y), width, height, edgecolor='none', 
                      facecolor=np.array(ellipse_color) / 255, lw=2)
    ax.add_patch(ellipse)
    ellipse.set_zorder(10)
    rect_height = height * 0.9
    
    shadow_rectangle = plt.Rectangle((center_x + width / 2 + 0.01, center_y - rect_height / 2 - 0.01), 
                                      rect_width, rect_height, color='gray', alpha=0.5)
    ax.add_patch(shadow_rectangle)
    
    rectangle = plt.Rectangle((center_x + width / 2, center_y - rect_height / 2), 
                              rect_width, rect_height, color=np.array(rectangle_color) / 255, zorder=9)
    ax.add_patch(rectangle)



# def draw_spacer_with_bracket(ax, center_x1, center_y, width=0.3, rect_width=0.2, aspect_ratio=3, 
                             # ellipse_color=[128, 0, 128], rectangle_color=[128, 0, 128], text='Spacer', fontsize=10):
    # center_x2 = center_x1 + 1
    # draw_spacer(ax, center_x1, center_y, width, rect_width, aspect_ratio, ellipse_color, rectangle_color)
    # draw_spacer(ax, center_x2, center_y, width, rect_width, aspect_ratio, ellipse_color, rectangle_color)
    
    
    # rect_height = width * aspect_ratio * 0.6  
    # rectangle = plt.Rectangle((center_x1 + width, center_y - rect_height / 2), 
                              # center_x2 - (center_x1 + width), rect_height, 
                              # color=np.array(colors['f']) / 255, alpha=0.9)
    # ax.add_patch(rectangle)
    # rectangle.set_zorder(5)
    
    
    # text_x = (center_x1 + center_x2) / 2  
    # text_x = center_x2+0.2  
    # text_y = center_y - rect_height*3.2 / 2 - 0.2  
    # ax.text(text_x, text_y, text, ha='center', fontsize=fontsize)

def draw_spacer_with_brackets(ax, center_x1_list, center_y, width=0.3, rect_width=0.2, aspect_ratio=3, 
                              ellipse_color=[128, 0, 128], rectangle_color=[128, 0, 128], text_list=list(), fontsize=5):
	
	rect_height = width * aspect_ratio * 0.6  
	text_y = center_y - rect_height * 1.6
	
	text_x_index=0
	
	for center_x1, text in zip(center_x1_list, text_list):
		center_x2 = center_x1 + 0.1
		
		
		draw_spacer(ax, center_x1, center_y, width, rect_width, aspect_ratio, ellipse_color, rectangle_color)
		# draw_spacer(ax, center_x2, center_y, width, rect_width, aspect_ratio, ellipse_color, rectangle_color)
		
		 
		# rectangle = plt.Rectangle((center_x1 + width, center_y - rect_height / 2), 
								  # center_x2 - (center_x1 + width), rect_height, 
								  # color=np.array(colors['f']) / 255, alpha=0.9)
		# ax.add_patch(rectangle)
		# rectangle.set_zorder(5)

		text_x = (center_x1 + center_x2) / 2  
		
		if text_x_index>0 and  center_x1_list[text_x_index]-center_x1_list[text_x_index-1]<1:
			text_y -= 0.3
		
		text_x_index+=1
		ax.text(text_x, text_y, text, ha='center', fontsize=fontsize)



def draw_dna_with_rectangles_at_positions(ax, rectangle_positions, rectangle_labels, width=0.05, height=1, color=colors['o'], fontsize=5, radius=0.05):


	 
	# text_y = height / 1.6
	text_y = -0.54* 1.6
	
	text_x_index=0


	for pos, label in zip(rectangle_positions, rectangle_labels):
		
 
		
		if text_x_index>0 and  rectangle_positions[text_x_index]-rectangle_positions[text_x_index-1]<1:
			text_y -= 0.3
		else:
			text_y = -0.54* 1.6

				# print(label)
				
		# width_new=max(width/max(1,(len(label)-3)),0.05)
		# width_new=0.05
		
		
		# radius=radius/max(1,(len(label)-3))
					
		text_x = pos + width / 2  	
		shadow_rectangle = FancyBboxPatch((pos + 0.015, -height / 2 - 0.015), width, height,
										   boxstyle=f"round,pad=0.01,rounding_size={radius}", color='gray', alpha=0.5)
		ax.add_patch(shadow_rectangle)
		shadow_rectangle.set_zorder(-10)

		
		rectangle = FancyBboxPatch((pos, -height / 2), width, height,
								   boxstyle=f"round,pad=0.01,rounding_size={radius}", color=np.array(color) / 255, alpha=0.9)
		ax.add_patch(rectangle)
		rectangle.set_zorder(10)

		ax.text(text_x, text_y, label, ha='center', va='bottom', fontsize=fontsize, color='black')
		
		text_x_index+=1		
		
		



def draw_crispr(ax,crispr_positions,crispr_labs,protein_positions,protein_labs):
	max_position = max(protein_positions+crispr_positions)
	min_position = min(protein_positions+crispr_positions)
	scale_factor = 12 /(max_position-min_position)


	protein_positions2 = [pos-min_position for pos in protein_positions]
	crispr_positions2 = [pos-min_position for pos in crispr_positions]
	
	scaled_positions = [pos * scale_factor+1 for pos in protein_positions2]
	scaled_positions2 = [pos * scale_factor+1 for pos in crispr_positions2]
	

	draw_dna_double_helix_2d_with_style(ax=ax, length=15, color1=colors['r'], color2=colors['b'], linewidth=2.5)
	
	# draw_spacer_with_bracket(ax, center_x1=scaled_positions2[0], center_y=0,width=0.25, rect_width=0.2,ellipse_color=colors['h'], rectangle_color=colors['y'], text='CRISPR Array')
	draw_spacer_with_brackets(ax, center_x1_list=scaled_positions2, center_y=0,width=0.25, rect_width=0.2,ellipse_color=colors['h'], rectangle_color=colors['y'], text_list=crispr_labs)	
	draw_dna_with_rectangles_at_positions(ax, scaled_positions,protein_labs)

 
